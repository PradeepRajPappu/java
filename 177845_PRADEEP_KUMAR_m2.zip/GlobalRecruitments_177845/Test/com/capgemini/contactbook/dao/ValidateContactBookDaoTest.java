package com.capgemini.contactbook.dao;


import static org.junit.Assert.*;

import org.junit.BeforeClass;
import org.junit.Test;

import com.capgemini.conatctbook.util.DBUtil;
import com.capgemini.contactbook.beans.EnquiryBean;
import com.capgemini.contactbook.exception.ContactBookException;



public class ValidateContactBookDaoTest {

	static EnquiryBean eb;
	static ContactBookDao dao;
	static ContactBookDaoImpl Dao;


	@BeforeClass
	public static void init()
	{	 Dao=new ContactBookDaoImpl();
	dao=new ContactBookDaoImpl();
	eb =new EnquiryBean("Pradeep","pappu","9652651520", "java", "pune");	

	}

	@Test
	public void TestToGetAllDetails() throws ContactBookException
	{

		assertNotNull(dao.getAllDetails());


	}
	@Test
	public void TestToAddEnquiry() throws ContactBookException
	{
		assertTrue("Test is true",validate(dao.addEnquiry(eb)));	
	}


	@Test
	public void TestGenerationForSequenceID() throws ContactBookException
	{
		int pid=Dao.generateEnqId();
		assertEquals(pid+1, Dao.generateEnqId());
	}

	@Test
	public void TestDBConnection() throws ContactBookException{

		assertNotNull(DBUtil.getConnection());


	}

	private boolean validate(int addEnquiry) {
		if(addEnquiry==0)
			return false;
		return true;
	}




}
