package com.capgemini.contactbook.service;

import java.util.List;

import com.capgemini.contactbook.beans.EnquiryBean;
import com.capgemini.contactbook.exception.ContactBookException;

public interface ContactBookService {

	int addEnquiry(EnquiryBean eb) throws ContactBookException;

	List<EnquiryBean> getAllDetails() throws ContactBookException;

	boolean validateDetails(EnquiryBean eb) throws ContactBookException;

	EnquiryBean getDetails(int id) throws ContactBookException;

}
