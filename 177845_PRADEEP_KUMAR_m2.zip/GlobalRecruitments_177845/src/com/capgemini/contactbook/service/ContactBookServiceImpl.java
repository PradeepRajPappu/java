package com.capgemini.contactbook.service;

import java.util.List;
import java.util.regex.Pattern;

import com.capgemini.contactbook.beans.EnquiryBean;
import com.capgemini.contactbook.dao.ContactBookDao;
import com.capgemini.contactbook.dao.ContactBookDaoImpl;
import com.capgemini.contactbook.exception.ContactBookException;


public class ContactBookServiceImpl implements ContactBookService{

	ContactBookDao cbDao=new ContactBookDaoImpl();
	@Override
	public int addEnquiry(EnquiryBean eb) throws ContactBookException {
		
		return cbDao.addEnquiry(eb);
	}
	@Override
	public List<EnquiryBean> getAllDetails() throws ContactBookException {
		return cbDao.getAllDetails();
	}

	
	@Override
	public boolean validateDetails(EnquiryBean eb) throws ContactBookException {
		
		
		Boolean flag=true;
		String nameEx="^[A-Z][a-z]{3,19}$";
		String phonenoEx="^[6-9][0-9]{9}$";
		if(!Pattern.matches((nameEx),eb.getfName()))
		{
			flag=false;
			throw new ContactBookException("first name should start with capitalletters and size should be 4 to 20 ......!\nex:Pradeep");
			
		}
		if(!Pattern.matches("^[a-z]{2,10}$",eb.getlName()))
		{
			flag=false;
			throw new ContactBookException("last name should start with small letters and size should be 2 to 10 ......!");
		}
		
		else if(!Pattern.matches(phonenoEx,eb.getContactNo()))
		{	
			flag=false;
			throw new ContactBookException("enter valid mobile number...!");
		}

		else if(!Pattern.matches("^[a-z]{2,10}$",eb.getpDomain()))
		{	
			flag=false;
			throw new ContactBookException("enter preffered domain in small letters ,size 2 to 10...!");
		}
		else if(!Pattern.matches("^[a-z]{2,10}$",eb.getpLocation()))
		{	
			flag=false;
			throw new ContactBookException("enter preffered location in small letters ,size 2 to 10...!");
		}




		return flag;
		
		
		
		
	}
	@Override
	public EnquiryBean getDetails(int id) throws ContactBookException {
		// TODO Auto-generated method stub
		return cbDao.getDetails(id);
	}

}
