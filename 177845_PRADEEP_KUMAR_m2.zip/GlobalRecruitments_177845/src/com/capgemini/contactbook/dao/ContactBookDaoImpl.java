package com.capgemini.contactbook.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.conatctbook.util.DBUtil;
import com.capgemini.contactbook.beans.EnquiryBean;
import com.capgemini.contactbook.exception.ContactBookException;





public class ContactBookDaoImpl implements ContactBookDao{
	Connection conn = null;

	Logger logger=Logger.getRootLogger();
	
	//For logger configuration
	public ContactBookDaoImpl()
	{
	PropertyConfigurator.configure("Resource/log4j.properties");
	
	}
	
			/*******************************************************************************************************
			 - Function Name	:	 addEnquiry(EnquiryBean eb)
			 - Input Parameters	:	 EnquiryBean eb
			 - Return Type		:	 int
			 - Throws			:  	 ContactBookException
			 - Author			:	Pradeep kumar
			 - Creation Date	:	02/05/2019
			 - Description		:	Adding details
			 ********************************************************************************************************/
	
	
	
	@Override
	public int addEnquiry(EnquiryBean eb) throws ContactBookException {
		
		conn = DBUtil.getConnection();
		if(conn!=null)
		logger.info("connection successfull");
		eb.setEnqryId(generateEnqId());
		//String sql="INSERT INTO enquiry VALUES(?,?,?,?,?,?)";
		try {
		PreparedStatement pst = conn.prepareStatement(QueryMapper.INSERTION_QUERY);
		//******parsing string to long because contact number in DB is number type	
		long cno=Long.parseLong(eb.getContactNo());
			pst.setInt(1,eb.getEnqryId());
			pst.setString(2, eb.getfName());
			pst.setString(3, eb.getlName());
			pst.setLong(4, cno);
			pst.setString(5, eb.getpDomain());
			pst.setString(6, eb.getpLocation());
			ResultSet rst=pst.executeQuery();
			
			logger.info("Details inserted successfull");
		} catch (SQLException e) {
			logger.error(e.getMessage());
		throw new ContactBookException("problem in inserting details :");
		}
		
		return eb.getEnqryId();
	}


	/*******************************************************************************************************
	 - Function Name	:	generateEnqId()
	 - Input Parameters	:	no parameters
	 - Return Type		:	integer type
	 - Throws			:  	ContactBookException
	 - Author			:	Pradeep kumar
	 - Creation Date	:	02/05/2019
	 - Description		:	To generate sequence from DataBase
	 ********************************************************************************************************/
	
	

	public int generateEnqId() throws ContactBookException {
		int eid = 0;
	//		String sql = "SELECT enquiries.NEXTVAL FROM dual";
			conn = DBUtil.getConnection();
			try {
				Statement stmt = conn.createStatement();
				ResultSet rst = stmt.executeQuery(QueryMapper.GENERATE_SEQUENCE_QUERY);
				rst.next();
				eid = rst.getInt(1);
			} catch (SQLException e) {
				
		//		logger.error(e.getMessage());
				throw new ContactBookException("Problem in generating enquiry id "+ e.getMessage());
			}
			logger.info("sequence generated successfully");
			//System.out.println(eid);
			return eid;
	
	}

	/*******************************************************************************************************
	 - Function Name	:	getAllDetails()
	 - Input Parameters	:	no parameters
	 - Return Type		:	list 
	 - Throws			:  	ContactBookException
	 - Author			:	Pradeep kumar
	 - Creation Date	:	02/05/2019
	 - Description		:	retrieving details
	 ********************************************************************************************************/
	


	@Override
	public List<EnquiryBean> getAllDetails() throws ContactBookException {
		//String sql="SELECT * from enquiry";
		List<EnquiryBean> mlist = new ArrayList<EnquiryBean>();
		conn = DBUtil.getConnection();
		try {
			Statement stmt = conn.createStatement();
			//	System.out.println(sql);
			ResultSet rst = stmt.executeQuery(QueryMapper.RETRIVE_ALL_DETAILS_QUERY);
			while (rst.next()) {

				EnquiryBean e = new EnquiryBean();
				e.setEnqryId(rst.getInt(1));
				e.setfName(rst.getString(2));
				e.setlName(rst.getString(3));
				e.setContactNo(rst.getString(4));
				e.setpDomain(rst.getString(5));
				e.setpLocation(rst.getString(6));
				mlist.add(e);
			}
		} catch (SQLException e) {
			logger.error(e.getMessage());
			throw new ContactBookException("Problem in fetching mobiles list"+ e.getMessage());
		}
		logger.info("Succeeded in fetching data from database ");
		return mlist;
	}

	@Override
	public EnquiryBean getDetails(int id) throws ContactBookException {
		EnquiryBean e; 
		String sql="Select * from enquiry where Enqryid=?";
		conn = DBUtil.getConnection();
		try {
			 e = new EnquiryBean();
			PreparedStatement pst = conn.prepareStatement(sql);
			pst.setInt(1,id);
			ResultSet rst = pst.executeQuery();
	while(rst.next())
	{
			e.setEnqryId(rst.getInt(1));
			e.setfName(rst.getString(2));
			e.setlName(rst.getString(3));
			e.setContactNo(rst.getString(4));
			e.setpDomain(rst.getString(5));
			e.setpLocation(rst.getString(6));
	
	}		
		} catch (SQLException e1) {
		throw new ContactBookException(e1.getMessage());
		}
		
		
		
		return e;
	}

	
}
