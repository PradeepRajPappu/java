package com.capgemini.contactbook.dao;

import java.util.List;

import com.capgemini.contactbook.beans.EnquiryBean;
import com.capgemini.contactbook.exception.ContactBookException;

public interface ContactBookDao {

	int addEnquiry(EnquiryBean eb) throws ContactBookException;

	List<EnquiryBean> getAllDetails() throws ContactBookException;

	EnquiryBean getDetails(int id) throws ContactBookException;

}
