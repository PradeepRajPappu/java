package com.capgemin.contactbook.ui;

import java.util.List;
import java.util.Scanner;
import java.util.regex.Pattern;

import com.capgemini.contactbook.beans.EnquiryBean;
import com.capgemini.contactbook.exception.ContactBookException;
import com.capgemini.contactbook.service.ContactBookService;
import com.capgemini.contactbook.service.ContactBookServiceImpl;

public class Client {

	public static void main(String[] args) {
		ContactBookService cbSer=new ContactBookServiceImpl();
		Scanner sc =new Scanner(System.in);
		do {
			System.out.println("**********Global Recruitments**********");
			System.out.println("1.Enter Enquiry Details");
			System.out.println("2.View All Enquiry Details");
			System.out.println("3.View Enquiry Details with EnquiryId :");
			System.out.println("0.Exit");
			System.out.println("***************************************");
			System.out.println("enter your choice: ");
			String choice = sc.next();
			if (Pattern.matches("[0-3]", choice)) {

				switch (choice) {
				//**********For Adding Details**************
				case "1":
					System.out.println("Enter First Name : ");
					String fName = sc.next();
					System.out.println("Enter Last Name : ");
					String lName = sc.next();
					System.out.println("Enter Contact Number : ");
					String contactNo = sc.next();
					System.out.println("Enter Preffered Domain : ");
					String pDomain = sc.next();
					System.out.println("Enter Preffered Location : ");
					String pLocation = sc.next();
					EnquiryBean eb = new EnquiryBean(fName, lName, contactNo,
							pLocation, pDomain);
					int enqId=0;
					try {
						if(cbSer.validateDetails(eb)){
							enqId = cbSer.addEnquiry(eb);
							if(enqId==0)
								System.out.println("Sorry no details found..!!");
							System.out.println("Thank you " +eb.getfName()+" "+eb.getlName()+" Your Unique Id is "+enqId);
						}
					} catch (ContactBookException e) {
						System.err.println(e.getMessage());
					}

					break;
				case "2":
					//**********For Retrieving Details**************
					List<EnquiryBean> mlist;
					try {
						mlist = cbSer.getAllDetails();
						if (mlist.size() == 0)
							System.out.println("Sorry no details found");
						else {
							System.out.println("*************************All Details*************************");
							System.out.println("Id    Firstname  Lastname   ContactNo  Preffered Domain  Preffered Location");
							for (EnquiryBean p : mlist)
							{
								System.out.printf("%-5d %-10s %-10s %-10s %-17s %-10s",p.getEnqryId(),p.getfName(),p.getlName(),p.getContactNo(),p.getpDomain(),p.getpLocation());
								System.out.println();	
							}
							System.out.println("**************************************************************");
							/*System.out.println("enqryID :"+p.getEnqryId()+"  ,Name :"+p.getfName()+
										" "+p.getlName()+"  ,ConatctNo :"+p.getContactNo()+
										"  ,PrefferedDomain :"+p.getpDomain()+"  ,PrefferdLocation :"+p.getpLocation());*/	

						}

					} catch (ContactBookException e) {
						System.err.println(e.getMessage());
					}

					break;
				case "3":
					System.out.println("enter id to get details ");
					String sid=sc.next();
					if(Pattern.matches("[0-9]{4}",sid)){


						int id=Integer.parseInt(sid);

						EnquiryBean p;
						try {

							p = cbSer.getDetails(id);
							System.out.println("********************deatils*********************************");
							System.out.println("Id    Firstname  Lastname   ContactNo  Preffered Domain  Preffered Location");
							System.out.printf("%-5d %-10s %-10s %-10s %-17s %-10s",p.getEnqryId(),p.getfName(),p.getlName(),p.getContactNo(),p.getpDomain(),p.getpLocation());
							System.out.println("************************************************************");
						} catch (ContactBookException e) {
							System.out.println(e.getMessage());
						}
					}else System.err.println("enter correct id");
					break;
				case "0":
					//**********For Exit**************
					System.exit(0);
					break;

				default:
					System.out.println("enter valid choice :");
				}
			} else
				System.out.println("enter valid choice :");
		} while (true);


	}
}