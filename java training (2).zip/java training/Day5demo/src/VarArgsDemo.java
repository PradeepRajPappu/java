import java.util.Arrays;


public class VarArgsDemo {
	
	
/*	public int add(int a,int b)
	{
		return a+b;
	}
	
	public int add(int a,int b,int c)
	{
		return a+b+c;
	}
	public int add(int a,int b,int c,int d)
	{
		return a+b+c+d;
	}*/

	public int add(int...arr){
		int sum=0;
		for(int ele:arr){
			sum+=ele;
		}
	return sum;
	
	}
	
	
	public static void main(String[] args) {
	/*	VarArgsDemo demo=new VarArgsDemo();

		System.out.println(demo.add(5,9));
		System.out.println(demo.add(5,9,7));
		System.out.println(demo.add(5,9,4,6));*/
		
		int arr[]={22,55,99,44,33,11};
		System.out.println("Orginal array: ");
		for(int ele:arr){System.out.print(" "+ele);}
		System.out.println();
		
		Arrays.sort(arr);
		
		System.out.println("After sorting:");
		for(int ele:arr){System.out.print(" "+ele);}
		System.out.println();
		
		
		System.out.println(Arrays.binarySearch(arr,22));
		System.out.println(Arrays.binarySearch(arr,77));
		
		
	}

}
