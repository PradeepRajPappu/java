
public class Pallindrome {
	
	public void str_pallidrome(String str){
	
		char[] str_arr=str.toCharArray();
		int i,j;
		for(i=0,j=str.length()-1;i<j;j--,i++)
		{
			if(str_arr[i]!=str_arr[j]){
				System.out.println(str+"not pallindrome ");
				return;
			}
			
				
		}
		System.out.println(str+" is pallindrome ");
		
	
			
		
	} 

	public static void main(String[] args) {
		Pallindrome obj =new Pallindrome();
		String str="pallap";
		
		obj.str_pallidrome(str);

	}

}
