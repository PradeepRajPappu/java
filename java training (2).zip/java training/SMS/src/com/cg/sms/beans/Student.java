package com.cg.sms.beans;

import java.time.LocalDate;

public class Student {
private String name;
private int age;
private String city;
private String state;
private LocalDate joiningdate;



public Student(String name, int age, String city, String state,
		LocalDate joiningdate) {
	super();
	this.name = name;
	this.age = age;
	this.city = city;
	this.state = state;
	this.joiningdate = joiningdate;
}
public LocalDate getJoiningdate() {
	return joiningdate;
}
public void setJoiningdate(LocalDate joiningdate) {
	this.joiningdate = joiningdate;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public int getAge() {
	return age;
}
public void setAge(int age) {
	this.age = age;
}
public String getCity() {
	return city;
}
public void setCity(String city) {
	this.city = city;
}
public String getState() {
	return state;
}
public void setState(String state) {
	this.state = state;
}
@Override
public String toString() {
	return "Student [name=" + name + ", age=" + age + ", city=" + city
			+ ", state=" + state + ", joiningdate=" + joiningdate + "]";
}

	


	
}
