package com.cg.sms.service;

import java.util.List;



import com.cg.sms.beans.Student;
import com.cg.sms.exception.StudentException;

public interface Serviceinterface {

	Student AddStudents(Student st);

	List<Student> showAllStudents();

	
	boolean validateStudent(Student student) throws StudentException;
	
	
}
