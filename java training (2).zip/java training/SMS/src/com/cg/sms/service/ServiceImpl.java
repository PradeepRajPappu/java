package com.cg.sms.service;

import java.util.List;


import java.util.regex.Pattern;

import com.cg.sms.beans.Student;
import com.cg.sms.dao.DaoImpl;
import com.cg.sms.dao.Daointerface;
import com.cg.sms.exception.StudentException;

public class ServiceImpl implements Serviceinterface{

	Daointerface dao= new DaoImpl();
	
	@Override
	public Student AddStudents(Student st) {
		// TODO Auto-generated method stub
		return dao.AddStudents(st);
	}

	@Override
	public List<Student> showAllStudents() {
		// TODO Auto-generated method stub
		return dao.showAllStudents();
	}

	@Override
	public boolean validateStudent(Student student) throws StudentException {
		String regx="[A-Z][a-z]{4,19}";
		//if(!student.getName().matches(regx))
		if(!Pattern.matches((regx),student.getName()))
			throw new StudentException("student name should start with capitalletters and size should be 5 to 20 ");
		if(student.getAge()<10)
			throw new StudentException("enter age in 2 digits :");
		if(student.getCity()==null){
			throw new StudentException("city should not be empty");	
		}
	if (!((student.getCity().equals("pune"))||(student.getCity().equals("mumbai"))||(student.getCity().equals("chennai"))||(student.getCity().equals("hyderabad")))){
		throw new StudentException("enter city correctly and should be in lowercase");
	}
		
		return true;
	
	
	

	}
	

	

}
