package com.cg.sms.dao;

import java.util.List;

import com.cg.sms.beans.Student;

public interface Daointerface {

	Student AddStudents(Student st);

	List<Student> showAllStudents();

}
