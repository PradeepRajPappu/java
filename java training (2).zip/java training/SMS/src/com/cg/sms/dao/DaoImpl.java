package com.cg.sms.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Set;


import com.cg.sms.beans.Student;



public class DaoImpl implements Daointerface{

	HashMap<Integer, Student> SMap =new HashMap<>();
	
	@Override
	public Student AddStudents(Student st) {
		SMap.put(st.getAge(), st);
		return st;
	}

	@Override
	public List<Student> showAllStudents() {
		List<Student> slist =new ArrayList<>(); 
		Set<Integer> keys =SMap.keySet();
		//if(keys.size()==0) 
		for(Integer k:keys){
		slist.add(SMap.get(k));
		}
		return slist;
	}

}
