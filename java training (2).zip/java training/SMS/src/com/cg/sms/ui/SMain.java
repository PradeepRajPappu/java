package com.cg.sms.ui;

import java.time.LocalDate;
import java.util.List;
import java.util.Scanner;




import com.cg.sms.beans.Student;
import com.cg.sms.exception.StudentException;
import com.cg.sms.service.ServiceImpl;
import com.cg.sms.service.Serviceinterface;

public class SMain {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		Serviceinterface sser= new ServiceImpl();
		
		do {
			System.out.println("1.Add students\n2.Display all students\n3.exit");
			System.out.println("enter your choice :");
			int choice = sc.nextInt();
			switch (choice) {
			case 1:
				System.out.println("enter student name:");
				String name = sc.next();
				System.out.println("enter student age:");
				int age = sc.nextInt();
				System.out.println("enter your city(pune,hyderabad,chennai,mumbai)");
				
				String city = sc.next();
				String state = null;
				
				
				if (city.equals("pune")) {
					state = "maharashtra";
				} else if (city.equals("hyderabad")) {
					state = "telangana";
				} else if (city.equals("chennai")) {
					state = "tamilnadu";
				} else if (city.equals("mumbai")) {
					state = "maharashtra";
				} 
//				else {System.out.println("enter city properly");}
				LocalDate joiningdate = LocalDate.now();
				Student st = new Student(name, age, city, state, joiningdate);
				try {
					if(sser.validateStudent(st))
					{
						Student s = sser.AddStudents(st);
						System.out.println("details of " + s.getName()+ " enter successfully ");
					}
				} catch (StudentException e) {
				System.err.println(e.getMessage());
				}
				
				break;
			case 2:
				List<Student> slist = sser.showAllStudents();
				for (Student e1 : slist) {
					System.out.println(e1);
				}
				break;
			case 3:
				System.exit(0);
			
			default:
				System.out.println("enter correct choice");

			}
		} while (true);
		

	}

}
