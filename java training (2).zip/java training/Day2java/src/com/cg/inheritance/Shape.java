package com.cg.inheritance;



abstract public class Shape {
	abstract public	double calculateArea();
}
	

