package com.cg.inheritance;

public class Person1 {
	private String name;
	private int age;
	
	public Person1()
	{
		this("unknown",0);
	//	name="unknown";
	//	age=0;
		System.out.println("default constructor of Person1");
	}
	public Person1(String name,int age){
	//	super();
		this.name=name;
		this.age=age;
		System.out.println("parametarised constructor of Person1");
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}	
}
