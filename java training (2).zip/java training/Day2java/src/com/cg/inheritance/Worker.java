package com.cg.inheritance;

public class Worker extends Person1 {
	private double dailywages;

	public Worker() {
		
		this(0.0,"unknown",0);
	}

	public Worker(double dailywages,String name, int age) {
		super(name,age);
	this.dailywages =dailywages;
	}
	
	

	public double getDailywages() {
		return dailywages;
	}

	public void setDailwages(double dailywages) {
		this.dailywages = dailywages;
	}
	
	public void displaywages(){
	System.out.println("dailywages:"+dailywages);
		
	}
	
}
