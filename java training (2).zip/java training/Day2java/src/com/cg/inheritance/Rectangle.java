package com.cg.inheritance;

public class Rectangle extends Shape{
private double width,height;
@Override
public double calculateArea(){
	return width *height;
}
public Rectangle(double width, double height) {
	super();
	this.width = width;
	this.height = height;
}
	
	
	
	
}
