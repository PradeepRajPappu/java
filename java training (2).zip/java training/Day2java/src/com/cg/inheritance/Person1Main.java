package com.cg.inheritance;

public class Person1Main {

	public static void main(String[] args) {
		/*Person1 p= new Person1();
		Person1 p1=new Person1("Pappu",22);
		p.setName("pradeep");
		p.setAge(22);
		System.out.println(p.getName()+":"+p.getAge());
		System.out.println(p1.getName()+":"+p1.getAge());*/
	
	/*Employee e = new Employee();
	Employee e1= new Employee(1001,2000);
	Employee e2= new Employee(1002,5000,"pappu",22);
	System.out.println(e.getName()+":"+e.getAge()+":"+e.getEmpno()+":"+e.getSalary());	
	System.out.println(e1.getName()+":"+e1.getAge()+":"+e1.getEmpno()+":"+e1.getSalary());
	System.out.println(e2.getName()+":"+e2.getAge()+":"+e2.getEmpno()+":"+e2.getSalary());	
	
	*/
	
	
/*	Person p= new Employee(1002,500,"pap",40);//implict upcasting
	p.display();
	
	Employee e= (Employee)p; //downcasting
	e.display();
	*/
	
	
		
		
		
	}

}
