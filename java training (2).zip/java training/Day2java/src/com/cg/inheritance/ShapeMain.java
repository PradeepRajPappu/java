package com.cg.inheritance;

public class ShapeMain {

	public static void main(String[] args) {
		Shape s= new Circle(5);
		Shape s1=new Rectangle(10,20);
		showArea(s);
		showArea(s1);
	}

	public static void showArea(Shape sh){
		System.out.println(sh.calculateArea());
		
	}
	
	
}
