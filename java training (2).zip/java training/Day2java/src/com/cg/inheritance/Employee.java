package com.cg.inheritance;

public class Employee extends Person1 {
	private int empno;
	private double salary;

	public Employee() {
	
	this(0,0.0);
		//this.empno = empno;
		//this.salary = salary;
	}

	public Employee(int empno,double salary){
		//super(name,age);
		this.empno=empno;
		this.salary=salary;
		System.out.println("employee parameterised constructor of Employee 1");
	}
	
	public Employee(int empno,double salary,String name, int age){
		super(name,age);
		this.empno=empno;
		this.salary=salary;
		System.out.println("employee parameterised constructor of Employee 2");
	}

	public int getEmpno() {
		return empno;
	}

	public void setEmpno(int empno) {
		this.empno = empno;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}
	
	
}
