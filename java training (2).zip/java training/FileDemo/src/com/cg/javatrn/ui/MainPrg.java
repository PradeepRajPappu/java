package com.cg.javatrn.ui;

import java.io.IOException;

import com.cg.javatrn.file.Demo1;

public class MainPrg {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Demo1 obj = new Demo1();
		try {
			obj.readFileData();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.err.print("Problem in File Reading "+e);
		}
		
	}

}
