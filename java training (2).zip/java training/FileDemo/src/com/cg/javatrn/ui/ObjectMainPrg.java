package com.cg.javatrn.ui;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import com.cg.javatrn.bean.Product;

public class ObjectMainPrg {

	public static void main(String[] args)  {
		// TODO Auto-generated method stub

		FileOutputStream fos=null;
		FileInputStream fis= null;
		ObjectOutputStream oos=null;
		ObjectInputStream ois =null;
		try {
			fos = new FileOutputStream("Resource/prod.txt");
			fis = new FileInputStream("Resource/prod.txt");
			Product prod = new Product(1, "Laptop");
			oos=new ObjectOutputStream(fos);
			 ois =new ObjectInputStream(fis);
			oos.writeObject(prod);
			
			// Read operation
			
			Product prod1=(Product)ois.readObject();
			System.out.println(prod1.getProdId()+" "+prod1.getProdName());
		
		//fos.wr
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			System.err.println("Problem in Object read write "+e);
		}
		catch (IOException e) {
			// TODO Auto-generated catch block
			System.err.println("Problem in Object read write "+e);
		}
		catch(ClassNotFoundException exp){
			System.err.println("Problem in class reading from object");
		}
		finally{
			try{
			if(fos!=null)
				
					fos.close();
			if(oos!=null)
				oos.close();
			}
				 catch (IOException e) {
					// TODO Auto-generated catch block
					System.err.println("Problem in closing resource object");
				}
			
		}
		
		
	
	}

}
