package com.cg.javatrn.file;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class Demo1 {

	String path="Resource/abc1.txt";
	public void readFileData() throws IOException {
		FileInputStream fis=null;
		try{
			fis=new FileInputStream(path);
			int ch=0;
			while((ch=fis.read())!=-1){
				
				System.out.print((char)ch);
			}
		}
		catch(FileNotFoundException exp){
			throw exp;
		}
		catch(IOException exp){
			throw exp;
		}
		finally{
	
			try {
				if(fis!=null)
				fis.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	

}
