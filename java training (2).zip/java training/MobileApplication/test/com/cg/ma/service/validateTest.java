package com.cg.ma.service;

import static org.junit.Assert.*;

import java.sql.Date;
import java.time.LocalDate;
import java.util.regex.Pattern;

import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;

import com.cg.ma.beans.Purchase;
import com.cg.ma.exception.MobileException;

public class validateTest {
static	MobileServiceInterface ser =new MobileServiceImpl();
	static Purchase p;
	@BeforeClass
	public static void init()
	{

	p=new Purchase("Sravan", "sravan@gmail.com", "9652651520",Date.valueOf(LocalDate.now()),"1001");
	}
	
/*	@Ignore
	@Test
	void testForDetails() throws MobileException
	{
		assertTrue(ser.validate(p));
	}*/
	
	
	
	@Test
	public void TestNameStartwithCaps()
	{
	String nameEx="^[A-Z][a-z]{4,19}$";
		assertEquals("test is correct",true, Pattern.matches((nameEx),p.getCustomername()));
	}
	
	@Test
	public void TestPhoneNumDigits()
	{
		String phonenoEx="^[6-9][0-9]{9}$";
		assertEquals("test is correct",true, Pattern.matches((phonenoEx),p.getPhoneno()));
	}
	
	@Test
	public void TestEmailIdFormat()
	{
		String EmailEx="^[A-Za-z0-9_-]+[@][a-z]+[.][a-z]+$";
		assertEquals("test is correct",true, Pattern.matches((EmailEx),p.getMailid()));
	}
	
	@Test
	public void TestMobileIdDigits()
	{
		String MobEx="^[0-9]{4}$";
		assertEquals("test is correct",true, Pattern.matches((MobEx),p.getMobileid()));
	}
	
	
	
	
	
	
	
	
	
	
	
	
}
