package com.cg.ma.dao;

import static org.junit.Assert.*;

import java.sql.Date;
import java.time.LocalDate;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.ma.beans.Purchase;
import com.cg.ma.exception.MobileException;
import com.cg.ma.util.DBUtil;

public class ValidateDaoTest {
	
	

	static MobileDaoInterface dao;
	static MobileDaoImpl Dao;
	
	static Purchase p;
	@BeforeClass
	public static void init()
	{
		dao=new MobileDaoImpl();
		Dao=new MobileDaoImpl();
	p=new Purchase("Sravan", "sravan@gmail.com", "9652651520",Date.valueOf(LocalDate.now()),"1001");
	}
	
	
	@Test
	public void TestToGetAllMobiles() throws MobileException
	{
		
			assertNotNull(dao.getAllMobiles());
		
		
	}
	
	
	@Test
	public void TestGenerationForSequenceID() throws MobileException
	{
		long pid=Dao.GeneratePurchaseId();
		assertEquals(pid+1, Dao.GeneratePurchaseId());
	}
	

	@Test
	public void TestAddCustomerDetails() throws MobileException
	{ 
		
		assertNotNull(dao.AddCustomerDetails(p));
		
		
	}
	
	
	
	
	@Test
	public void TestGeneratePurchaseId() throws MobileException{
	
		assertNotNull(Dao.GeneratePurchaseId());
		
	
	}
	
	
	
	@Test
	public void TestDBConnection() throws MobileException{
	
		assertNotNull(DBUtil.getConnection());
		
	
	}
	
	
	
	
	
	
	
	
}
