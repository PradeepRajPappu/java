package com.cg.ma.service;

import java.sql.SQLException;
import java.util.List;

import com.cg.ma.beans.Mobiles;
import com.cg.ma.beans.Purchase;
import com.cg.ma.exception.MobileException;

public interface MobileServiceInterface {

	Purchase AddCustomerDetails(Purchase p) throws MobileException;
	
//	boolean UpdateMobQuantity(Purchase p) throws MobileException;
	
	
	

	List<Mobiles> getAllMobiles() throws MobileException;


	List<Mobiles> getMobPriceRange(long startprice, long endprice) throws MobileException;

	String DeleteMobile(String mobid) throws MobileException;

	List<Purchase> getAllPurchaseDetails(String mobile_id) throws MobileException;

	Purchase getPurchaseDetailsByPID(long purchaseid) throws MobileException;

	boolean validate(Purchase p) throws MobileException;

}
