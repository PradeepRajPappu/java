package com.cg.ma.service;

import java.sql.SQLException;
import java.util.List;
import java.util.regex.Pattern;

import com.cg.ma.beans.Mobiles;
import com.cg.ma.beans.Purchase;
import com.cg.ma.dao.MobileDaoImpl;
import com.cg.ma.dao.MobileDaoInterface;
import com.cg.ma.exception.MobileException;


public class MobileServiceImpl implements MobileServiceInterface {

	MobileDaoInterface dao=new MobileDaoImpl();
	@Override
	public Purchase AddCustomerDetails(Purchase p) throws MobileException{

		/*if(dao.UpdateMobQuantity(p))
		{
		return dao.AddCustomerDetails(p);
		}
		return null;*/
		return dao.AddCustomerDetails(p);
		}
	@Override
	public List<Mobiles> getAllMobiles() throws MobileException {
		// TODO Auto-generated method stub
		return dao.getAllMobiles();
	}
		@Override
			public boolean validate(Purchase p) throws MobileException {
				Boolean flag=true;
				String nameEx="^[A-Z][a-z]{4,19}$";
				String phonenoEx="^[6-9][0-9]{9}$";
				//if(!student.getName().matches(regx))
				if(!Pattern.matches((nameEx),p.getCustomername()))
				{
					flag=false;
					throw new MobileException("customer name should start with capitalletters and size should be 5 to 20 ......!");
				}
				else if(!Pattern.matches("^[A-Za-z0-9_-]+[@][a-z]+[.][a-z]+$",p.getMailid()))
				{	
					flag=false;
					throw new MobileException("enter valid MailId ..!\nex:pradeep_kumar007@gmail.com");
				}	

				else	if(!Pattern.matches(phonenoEx,p.getPhoneno()))
				{	
					flag=false;
					throw new MobileException("enter valid mobile number...!");
				}

				else	if(!Pattern.matches("^[0-9]{4}$",p.getMobileid()))
				{	
					flag=false;
					throw new MobileException("enter valid mobile id of 4 digits which is existing in mobiles table...!");
				}




				return flag;
	}
	
	
	@Override
	public List<Mobiles> getMobPriceRange(long startprice, long endprice) throws MobileException {
		
		return dao.getMobPriceRange(startprice,endprice);
	}
	
	
	
	@Override
	public String DeleteMobile(String mobid) throws MobileException {
		
		return dao.DeleteMobile(mobid);
	}

	@Override
	public List<Purchase> getAllPurchaseDetails(String mobile_id) throws MobileException {
		
		return dao.getAllPurchaseDetails(mobile_id);
	}
	@Override
	public Purchase getPurchaseDetailsByPID(long purchaseid) throws MobileException {

		return dao.getPurchaseDetailsByPID(purchaseid);
	}
	
	
	

}
