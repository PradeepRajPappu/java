package com.cg.ma.ui;

import java.sql.Date;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;
import java.util.Scanner;
import java.util.regex.Pattern;

import com.cg.ma.beans.Mobiles;
import com.cg.ma.beans.Purchase;
import com.cg.ma.exception.MobileException;
import com.cg.ma.service.MobileServiceImpl;
import com.cg.ma.service.MobileServiceInterface;


public class MobileMain {
	public static void main(String[] args) throws SQLException {	
		MobileServiceInterface mser=new MobileServiceImpl();
	Scanner sc=new Scanner(System.in);
	do {
		
		System.out.println("1.Add Purchase Details");
		System.out.println("2.Display All Mobiles");
		System.out.println("3.Search Mobile");
		System.out.println("4.Delete Mobile");
		System.out.println("5.Display PurchaseDetails Using MobileID");
		System.out.println("6.Display PurchaseDetails Using PurchaseId");
		
		System.out.println("7.Exit");
		System.out.println("enter your choice :");
		String choice = sc.next();
		if(Pattern.matches("[1-7]",choice)){
		switch (choice) {
		case "1":
				System.out.println("enter consumer name");
					String customername=sc.next();
					System.out.println("enter mailid:");
					String mailid=sc.next();
					System.out.println("enter phone number:");
					String phoneno=sc.next();
					Date date=Date.valueOf(LocalDate.now());
					System.out.println("enter mobile id:");
					String mobileid=sc.next();
			Purchase p = new Purchase(customername, mailid, phoneno,date,mobileid);		
			
			try {
				if(mser.validate(p))
				{
				p=mser.AddCustomerDetails(p);
				System.out.println("entered details successfully with purchaseid :"+p.getPurchaseid());
				
				
				}
			} catch (MobileException e1) {

				System.err.println(e1.getMessage());
			}
			
			break;
		
			
			
		case "2":
			List<Mobiles> mlist;
			try {
				mlist = mser.getAllMobiles();
				if(mlist.size()==0)
					System.out.println("no products available");
				else {
					for(Mobiles p1:mlist)
						System.out.println(p1);
				}
				
			} catch (MobileException e) {
				System.out.println(e.getMessage());
			}
				break;
		case "3":
			long startprice,endprice;
			System.out.println("enter price range to search");
			System.out.println("enter start price range");
			startprice=sc.nextLong();
			System.out.println("enter end price range");
			endprice=sc.nextLong();
			List<Mobiles> mslist;
		try {
			mslist = mser.getMobPriceRange(startprice,endprice);
			if(mslist.size()==0)
				System.out.println("no products available");
			else {
				for(Mobiles p1:mslist)
					System.out.println(p1);
			}
			
			} catch (MobileException e) {
			System.out.println(e.getMessage());
			}
			break;
	
			case "4":
				System.out.println("Enter Mobileid to delete that mobiles :");
				String mobid=sc.next();
				try {
					String id;
					id = mser.DeleteMobile(mobid);
					System.out.println("The Mobiles with Id :"+mobid+" are Deleted..!");
					} catch (MobileException e) {
						System.out.println("Problem in deleting..! "+e.getMessage());
					}
				break;
			
			case "5":
				System.out.println("Enter mobileid to get Purchase details");	
				String mobile_id=sc.next();
					
				
				
				List<Purchase> plist;
				try {
					plist = mser.getAllPurchaseDetails(mobile_id);
					if(plist.size()==0)
						System.out.println("No purchase details available");
					else {
						for(Purchase p1:plist)
							System.out.println(p1);
					}
					
				} catch (MobileException e) {
					System.out.println(e.getMessage());
				}
					break;
				
				
			case "6":
				System.out.println("Enter purchaseId to get purchase details :");
				long purchaseid=0;
				String spurchaseid=sc.next();
				if(Pattern.matches("[0-9]{3}",spurchaseid))	
				{
				purchaseid=	Long.parseLong(spurchaseid);
				
			try {
				Purchase p1=mser.getPurchaseDetailsByPID(purchaseid);
				System.out.println(p1);
			
			} catch (MobileException e) {
				System.err.println(e.getMessage());
			}
				}
				else
					System.err.println("enter valid purchase id..!");
				
				
				
				break;
					
					
			case "7":
			System.exit(0);
			break;

		default:
			System.out.println("enter valid choice ");

		}
		}else System.err.println("enter a valid choice ");
	} while (true);
	
	
	
	
	
	
	}
}
