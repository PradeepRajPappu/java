package com.cg.ma.dao;

public interface QueryMapper {
	public static final String RETRIVE_ALL_MOBILES_QUERY="SELECT mobileid,name,price,quantity FROM mobiles";
	public static final String SEARCH_MOBILES_PRICE_QUERY="SELECT * FROM mobiles WHERE price BETWEEN ? AND ?";
	public static final String INSERT_PURCHASE_DETAILS_QUERY="INSERT INTO purchasedetails VALUES(?,?,?,?,sysdate,?)";
	public static final String UPDATE_MOBILE_QUANTITY_QUERY="UPDATE mobiles SET quantity=quantity-1 WHERE mobileid=?";
	public static final String DELETE_PURCHASE_DETAILS__MOBID_QUERY="DELETE from purchasedetails where mobileid = ?";
	public static final String DELETE_MOBILES_MOBID_QUERY="DELETE from mobiles where mobileid = ?";
	public static final String GENERATE_PURCHASEID_SEQUENCE="SELECT PurchaseId_seq.NEXTVAL FROM dual";
	public static final String RETRIVE_PURCHASE_DETAILS_WITH_MOBID_QUERY="SELECT purchaseid,cname,mailid,phoneno,purchasedate FROM purchasedetails WHERE mobileid = ?";
	public static final String RETRIVE_PURCHASE_DETAILS_WITH_PURCHASEID_QUERY="SELECT purchaseid,cname,mailid,phoneno,purchasedate,mobileid FROM purchasedetails WHERE purchaseid = ?";
	
	
	
	
	
}
