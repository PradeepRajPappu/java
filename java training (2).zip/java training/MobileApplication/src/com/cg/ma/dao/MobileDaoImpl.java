package com.cg.ma.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.ma.beans.Mobiles;
import com.cg.ma.beans.Purchase;
import com.cg.ma.exception.MobileException;
import com.cg.ma.util.DBUtil;


public class MobileDaoImpl implements MobileDaoInterface{
	Connection conn = null;

	
	Logger logger=Logger.getRootLogger();
	public MobileDaoImpl()
	{
	PropertyConfigurator.configure("Resource/log4j.properties");
	
	}
	
	//------------------------ 1. Mobile Application --------------------------
		/*******************************************************************************************************
		 - Function Name	:	 AddCustomerDetails(Purchase p)
		 - Input Parameters	:	(Purchase p
		 - Return Type		:	Purchase
		 - Throws			:  	Exception
		 - Author			:	Pradeep kumar
		 - Creation Date	:	18/11/2016
		 - Description		:	Adding Purchase
		 ********************************************************************************************************/
	
	@Override
	public Purchase AddCustomerDetails(Purchase p) throws MobileException {

		
		try {
			conn = DBUtil.getConnection();
			conn.setAutoCommit(false);
			logger.info("connection established successfully");
			
	
			PreparedStatement pst2 = conn.prepareStatement(QueryMapper.UPDATE_MOBILE_QUANTITY_QUERY);
			pst2.setString(1,p.getMobileid());
			ResultSet rst2=pst2.executeQuery();
		//	pst2.executeUpdate();
			System.out.println("quantityupdate");
			logger.info("Update quantity successfull");
			


		//	String sqli = "INSERT INTO purchasedetails VALUES(?,?,?,?,sysdate,?)";	
			p.setPurchaseid(GeneratePurchaseId());
			//conn = DBUtil.getConnection();
			
			
			PreparedStatement psti = conn.prepareStatement(QueryMapper.INSERT_PURCHASE_DETAILS_QUERY);
			psti.setLong(1, p.getPurchaseid());
			psti.setString(2, p.getCustomername());
			psti.setString(3, p.getMailid());
			//		psti.setDate(4,p.getDate());
			psti.setString(4,p.getPhoneno());
			psti.setString(5,p.getMobileid());
			ResultSet rst1=psti.executeQuery();
			psti.executeUpdate();
			logger.info("Purchase details inserted successfull");
			conn.commit();
			//		 conn.setAutoCommit(true);

		} catch (SQLException e) {
			try {
				conn.rollback();
			} catch (SQLException e1) {
				throw new MobileException("rolled back....! -> Details not insterted ");

			}
			logger.error(e.getMessage());
			throw new MobileException("No mobiles available with mobileid "+p.getMobileid()+" Details "+ e.getMessage());

		}
		
		
		
			/*//	System.out.println(p);
				finally{
					System.out.println("f");
					conn=null;
						try {
							conn.close();
							
						} catch (SQLException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						
				}*/

		return p;
		
	}
	


	public long GeneratePurchaseId() throws MobileException {
		long pid = 0;
	//	String sql = "SELECT PurchaseId_seq.NEXTVAL FROM dual";
		conn = DBUtil.getConnection();
		try {
			Statement stmt = conn.createStatement();
			ResultSet rst = stmt.executeQuery(QueryMapper.GENERATE_PURCHASEID_SEQUENCE);
			rst.next();
			pid = rst.getLong(1);
		} catch (SQLException e) {
			logger.error(e.getMessage());
			throw new MobileException("Problem in generating product id "+ e.getMessage());
		}
		return pid;
	}





	@Override
	public List<Mobiles> getAllMobiles() throws MobileException {

		String sql="SELECT * from mobiles";
		List<Mobiles> mlist = new ArrayList<Mobiles>();
		conn = DBUtil.getConnection();
		try {
			Statement stmt = conn.createStatement();
			//	System.out.println(sql);
			ResultSet rst = stmt.executeQuery(sql);
			while (rst.next()) {

				Mobiles p = new Mobiles();
				p.setMobileid(rst.getString("mobileid"));
				p.setMobilename(rst.getString("name"));
				p.setMobileprice(rst.getDouble("price"));
				p.setQuantity(rst.getString("quantity"));
				mlist.add(p);
			}
		} catch (SQLException e) {
			throw new MobileException("Problem in fetching mobiles list"+ e.getMessage());
		}
		return mlist;

	}



	@Override
	public List<Mobiles> getMobPriceRange(long startprice, long endprice) throws MobileException {

	//	String sql="SELECT * from mobiles where price BETWEEN ? AND ?";
		List<Mobiles> mlist = new ArrayList<Mobiles>();
		conn = DBUtil.getConnection();
		try {
			PreparedStatement pst = conn.prepareStatement(QueryMapper.SEARCH_MOBILES_PRICE_QUERY);
			pst.setLong(1, startprice);
			pst.setLong(2, endprice);

			ResultSet rst = pst.executeQuery();
			while (rst.next()) {
				Mobiles p = new Mobiles();
				p.setMobileid(rst.getString("mobileid"));
				p.setMobilename(rst.getString("name"));
				p.setMobileprice(rst.getDouble("price"));
				p.setQuantity(rst.getString("quantity"));
				mlist.add(p);
			}
		} catch (SQLException e) {
			throw new MobileException("Problem in fetching mobiles list :"+ e.getMessage());
		}
		return mlist;
	}
	@Override
	public String DeleteMobile(String mobid) throws MobileException {
//		String sql1="Delete from purchasedetails where mobileid = ?";
//		String sql="Delete from mobiles where mobileid = ?";
		conn = DBUtil.getConnection();
		try {
			PreparedStatement pst1 = conn.prepareStatement(QueryMapper.DELETE_PURCHASE_DETAILS__MOBID_QUERY);
			PreparedStatement pst = conn.prepareStatement(QueryMapper.DELETE_MOBILES_MOBID_QUERY);
			pst1.setString(1,mobid);
			pst.setString(1,mobid);
			ResultSet rst1 = pst1.executeQuery();
			ResultSet rst = pst.executeQuery();
			pst.executeUpdate();
		} catch (SQLException e) {
			throw new MobileException("Problem in fetching mobiles list"+ e.getMessage());
		}
		return mobid;
	}

	@Override
	public List<Purchase> getAllPurchaseDetails(String mobile_id) throws MobileException {
		
		List<Purchase> plist = new ArrayList<Purchase>();
		conn = DBUtil.getConnection();
		try {
			PreparedStatement pst = conn.prepareStatement(QueryMapper.RETRIVE_PURCHASE_DETAILS_WITH_MOBID_QUERY);
			pst.setString(1,mobile_id);
			
			
			ResultSet rst = pst.executeQuery();
			while (rst.next()) {
				Purchase p = new Purchase();
				p.setPurchaseid(rst.getLong("purchaseid"));
				p.setCustomername(rst.getString("cname"));
				p.setPhoneno(rst.getString("phoneno"));
			    p.setDate(rst.getDate("purchasedate"));
				p.setMailid(rst.getString("mailid"));
						
				plist.add(p);
			}
		} catch (SQLException e) {
			throw new MobileException("Problem in fetching purchase list"+ e.getMessage());
		}
		return plist;
		
	
	}






	@Override
	public Purchase getPurchaseDetailsByPID(long purchaseid) throws MobileException {
			
		Purchase p= new Purchase();	
			try {
				conn = DBUtil.getConnection();
				PreparedStatement pst = conn.prepareStatement(QueryMapper.RETRIVE_PURCHASE_DETAILS_WITH_PURCHASEID_QUERY);
				pst.setLong(1,purchaseid);
		
				ResultSet rst = pst.executeQuery();
				rst.next();
				p.setPurchaseid(rst.getLong("purchaseid"));
				p.setCustomername(rst.getString("cname"));
				p.setPhoneno(rst.getString("phoneno"));
				p.setDate(rst.getDate("purchasedate"));
				p.setMailid(rst.getString("mailid"));
				p.setMobileid(rst.getString("mobileid"));

			} catch (MobileException e) {
				throw new MobileException("details not found with purchaseid"+purchaseid);
			} catch (SQLException e) {
				throw new MobileException("Details not found with purchaseid"+purchaseid);		
				
			
			}
		
		return p;
		
	}


	
	
	
	
	

	
	
	
	


}
