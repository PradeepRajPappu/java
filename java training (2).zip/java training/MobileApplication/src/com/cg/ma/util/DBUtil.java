package com.cg.ma.util;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import com.cg.ma.exception.MobileException;



public class DBUtil {
	private static Connection conn=null ;

	public static Connection getConnection() throws MobileException{
	
FileInputStream fis= null;
try {
	fis = new FileInputStream("Resource/MJDBC.properties");
	Properties prop =new Properties();
	prop.load(fis);
	String driver=prop.getProperty("JDBC.Driver");
	String url=prop.getProperty("JDBC.URL");
	String user=prop.getProperty("JDBC.Userid");
	String password=prop.getProperty("JDBC.password");
	/*System.out.println(driver);
	System.out.println(url);
	System.out.println(user);
	System.out.println(password);*/
	
	if (conn == null) {
	Class.forName(driver);
	System.out.println("driver found");
	 conn = DriverManager.getConnection(url,user,password);
	System.out.println("connection established");
	}
	} catch (ClassNotFoundException e) {
		throw new MobileException("Driver not found"+ e.getMessage());
	} catch (SQLException e) {
		throw new MobileException(
				"Problem in establishng connection" + e.getMessage());
	} catch (FileNotFoundException e) {
	System.err.println(e.getMessage());
	} catch (IOException e) {
	System.err.println(e.getMessage());
	}
	
	

finally{
	if(fis!=null)
		try {
			fis.close();
		} catch (IOException e) {
			System.err.println(e.getMessage());
		}
		}

	return conn;
	}
}
		
/*		

if (conn == null) {
	try {
		Class.forName("oracle.jdbc.driver.OracleDriver");
		System.out.println("driver found");
		 conn = DriverManager.getConnection("jdbc:oracle:thin:@ndaoracle:1521:ORCL11g","lab01trg15", "lab01oracle");
		System.out.println("connection established");
	} catch (ClassNotFoundException e) {
		throw new MobileException("Driver not found"+ e.getMessage());
	} catch (SQLException e) {
		throw new MobileException(
				"Problem in establishng connection" + e.getMessage());

	}
}	
return conn;
}
}
		*/
		
		
		
		
		
		
	


