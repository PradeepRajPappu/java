package com.cg.ma.beans;

public class Mobiles {
private String mobileid;
private String mobilename;
private double mobileprice;
private String quantity;


public Mobiles(String mobileid, String mobilename, double mobileprice,
		String quantity) {
	super();
	this.mobileid = mobileid;
	this.mobilename = mobilename;
	this.mobileprice = mobileprice;
	this.quantity = quantity;
}
public Mobiles() {
	// TODO Auto-generated constructor stub
}
public String getMobileid() {
	return mobileid;
}
public void setMobileid(String mobileid) {
	this.mobileid = mobileid;
}
public String getMobilename() {
	return mobilename;
}
public void setMobilename(String mobilename) {
	this.mobilename = mobilename;
}
public double getMobileprice() {
	return mobileprice;
}
public void setMobileprice(double mobileprice) {
	this.mobileprice = mobileprice;
}
public String getQuantity() {
	return quantity;
}
public void setQuantity(String quantity) {
	this.quantity = quantity;
}
@Override
public String toString() {
	return "Mobiles [mobileid=" + mobileid + ", mobilename=" + mobilename
			+ ", mobileprice=" + mobileprice + ", quantity=" + quantity + "]";
}
	
	
}
