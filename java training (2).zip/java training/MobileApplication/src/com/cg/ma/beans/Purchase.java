package com.cg.ma.beans;

import java.sql.Date;
import java.time.LocalDate;

public class Purchase {
private	long purchaseid;
private	String customername;
private	String mailid;
private	String phoneno;
private	Date date;
private String mobileid;

	
	
	public Purchase( String customername, String mailid,
		String phoneno, Date date, String mobileid) {
	super();
	//this.purchaseid = ;
	this.customername = customername;
	this.mailid = mailid;
	this.phoneno = phoneno;
	this.date = date;
	this.mobileid = mobileid;
}
	public Purchase() {
		// TODO Auto-generated constructor stub
	}
	public String getMobileid() {
	return mobileid;
}
public void setMobileid(String mobileid) {
	this.mobileid = mobileid;
}
	public long getPurchaseid() {
		return purchaseid;
	}
	public void setPurchaseid(long l) {
		this.purchaseid = l;
	}
	public String getCustomername() {
		return customername;
	}
	public void setCustomername(String customername) {
		this.customername = customername;
	}
	public String getMailid() {
		return mailid;
	}
	public void setMailid(String mailid) {
		this.mailid = mailid;
	}
	public String getPhoneno() {
		return phoneno;
	}
	public void setPhoneno(String phoneno) {
		this.phoneno = phoneno;
	}

	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	@Override
	public String toString() {
		return "Purchase [purchaseid=" + purchaseid + ", customername="
				+ customername + ", mailid=" + mailid + ", phoneno=" + phoneno
				+ ", date=" + date + "]";
	}
	
	
	
}
