package com.cg.demos;

import java.util.Scanner;
import java.util.regex.Pattern;

public class RegExDemo {

	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
		System.out.println("enter pattern:");
		String pattern= sc.next();
		System.out.println("enter your string:");
		String str=sc.next();
		if(Pattern.matches(pattern,str))
		System.out.println("found");
		else 
			System.out.println("not found");
		

	}

}
