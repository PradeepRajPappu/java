package com.cg.main;

import java.util.HashSet;
import java.util.Set;

public class Main {

	public static void main(String[] args) {
	Set set =new HashSet<>();
	set.add("B");
	set.add("B");
	set.add("D");
	set.add("A");
	System.out.println(set);
	}

}
