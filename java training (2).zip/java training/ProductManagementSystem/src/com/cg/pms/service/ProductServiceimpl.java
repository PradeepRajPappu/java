package com.cg.pms.service;

import java.util.List;

import com.cg.pms.beans.Order;
import com.cg.pms.beans.Product;
import com.cg.pms.dao.ProductDao;
import com.cg.pms.dao.ProductDaoImpl;
import com.cg.pms.exception.ProductException;

public class ProductServiceimpl implements ProductService {
	ProductDao pdao= new ProductDaoImpl();
	
	
	
	@Override
	public int addProduct(Product product) {
		return pdao.addProduct(product);
	}

	@Override
	public Product searchProduct(int productId) throws ProductException {
		// TODO Auto-generated method stub
		return pdao.searchProduct(productId);
	}

	@Override
	public int deleteProduct(int productId) throws ProductException {
		// TODO Auto-generated method stub
		return pdao.deleteProduct(productId);
	}

	@Override
	public List<Product> showAllProduct() throws ProductException {
		// TODO Auto-generated method stub
		return pdao.showAllProduct();
	}

	@Override
	public int addOrder(Order order) {
		order.setAmount(order.getQuantity()*order.getProduct().getPrice());
		return pdao.addOrder(order);
	}

	@Override
	public boolean validateProduct(Product product) throws ProductException {
		if(product.getPrice()<=0){
					throw new ProductException("Product quantity should not be less than 0");
		}
					return true;
	}

	@Override
	public boolean validateOrder(Order order) throws ProductException {
		if(order.getQuantity()<=0){
			throw new ProductException("Order quantity should not be less than 0");
		}
			return true;
	}

}
