package com.cg.pms.service;

import java.util.List;

import com.cg.pms.beans.Order;
import com.cg.pms.beans.Product;
import com.cg.pms.exception.ProductException;

public interface ProductService {
int addProduct(Product product);
Product searchProduct(int productId) throws ProductException;
int deleteProduct(int productId)  throws ProductException;
List<Product> showAllProduct()   throws ProductException;
int addOrder(Order order);
boolean validateProduct(Product product)  throws ProductException;
boolean validateOrder(Order order)  throws ProductException;
}
