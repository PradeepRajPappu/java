package com.cg.pms.pl;

import java.util.List;
import java.util.Scanner;

import com.cg.pms.beans.Order;
import com.cg.pms.beans.Product;
import com.cg.pms.exception.ProductException;
import com.cg.pms.service.ProductService;
import com.cg.pms.service.ProductServiceimpl;



public class ProductMain {

	public static void main(String[] args) {
		Scanner sc =new Scanner(System.in);
		ProductService Pser= new ProductServiceimpl();
		do {
			System.out
					.println("Menu\n1.Add product\n2.Delete product\n3.Show product list\n4.Place order\n5.Exit\n");
			System.out.println("enter your choice\n");
			int choice;
			choice = sc.nextInt();
			switch (choice) {
			case 1:
				System.out.println("enter product name:");
				String pname = sc.next();
				System.out.println("enter product price:");
				double price = sc.nextDouble();
				Product p = new Product(pname, price);
				try {
					if (Pser.validateProduct(p)) {
						int pid = Pser.addProduct(p);
						System.out.println("Product added with product id: "
								+ pid);
					}

				} catch (Exception e) {
					e.getMessage();
				}
				break;
			case 2:
				System.out.println("enter product id to delete");
				int pid1 = sc.nextInt();
				try {
					Pser.deleteProduct(pid1);
				} catch (ProductException e) {

					System.out.println(e.getMessage());
				}

				break;
			case 3:
				try {
					List<Product> plist = Pser.showAllProduct();
					for (Product p1 : plist) {
						System.out.println(p1.toString());
					}
				} catch (ProductException e1) {
					System.out.println(e1.getMessage());
				}
				break;
			case 4:
				System.out.println("enter product id to order");
				int pid2 = sc.nextInt();
				System.out.println("enter quantity");
				int qty = sc.nextInt();
				Product p1;
				try {
					p1 = Pser.searchProduct(pid2);
					Order order = new Order(p1, qty, 0);
					int oid = Pser.addOrder(order);
					System.out.println("order placed with id " + oid);
					System.out.println("you need to pay amount "+ order.getAmount());
				} catch (ProductException e3) {
					System.out.println(e3.getMessage());
				}

				break;
			case 5:
				System.exit(0);
				break;
			default:
				System.out.println("wrong entry..!try another");

			}
		} while (true);
		}
	}


