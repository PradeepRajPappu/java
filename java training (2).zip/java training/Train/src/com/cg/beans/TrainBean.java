package com.cg.beans;

import java.time.LocalDate;

public class TrainBean {

	private int trainId;
	private String trainType;
	private int seats;
	private int platformno;
	
	
	
	
	public TrainBean( String trainType, int seats, int platformno) {
		super();
		
		this.trainType = trainType;
		this.seats = seats;
		this.platformno = platformno;
	}
	public TrainBean() {
		// TODO Auto-generated constructor stub
	}
	public int getTrainId() {
		return trainId;
	}
	public void setTrainId(int trainId) {
		this.trainId = trainId;
	}
	public String getTrainType() {
		return trainType;
	}
	public void setTrainType(String trainType) {
		this.trainType = trainType;
	}
	public int getSeats() {
		return seats;
	}
	public void setSeats(int seats) {
		this.seats = seats;
	}
	public int getPlatformno() {
		return platformno;
	}
	public void setPlatformno(int platformno) {
		this.platformno = platformno;
	}
	@Override
	public String toString() {
		return "TrainBean [trainId=" + trainId + ", trainType=" + trainType
				+ ", seats=" + seats + ", platformno=" + platformno + "]";
	}
	
	
	
}
