package com.cg.dao;

import java.sql.Connection;




import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


import com.cg.beans.TrainBean;
import com.cg.dbutil.Dbutil;
import com.cg.exception.TrainException;

public class DaoImpl implements DaoInterface{

	Connection conn=null;
	
	@Override
	public int addDetails(TrainBean tb) throws TrainException {
		
		tb.setTrainId(generateid());
		
		conn = Dbutil.getConnection();
		String sql="insert into train values(?,?,?,?)";
		try {
			PreparedStatement pst=conn.prepareStatement(sql);
				pst.setInt(1,tb.getTrainId());
				pst.setString( 2,tb.getTrainType());
				pst.setInt(3,tb.getSeats());
				pst.setInt(4,tb.getPlatformno());
				ResultSet rst=pst.executeQuery();
		
		
		} catch (SQLException e) {
			throw new TrainException("failed in inserting..!");
		}
		
		return tb.getTrainId();
	}

	private int generateid() throws TrainException {
		conn = Dbutil.getConnection();
		String sql="Select seq.nextval from dual";
		int id=0;
		try {
			Statement stmt=conn.createStatement();
			ResultSet rst = stmt.executeQuery(sql);
			rst.next();
			id = rst.getInt(1);
			
			
		} catch (SQLException e) {
		throw new TrainException("sequence genertion failed:");
		}
		
		
		return id;
	}

	@Override
	public TrainBean getDetailsWithId(int id1) throws TrainException {
		conn = Dbutil.getConnection();
		TrainBean tb= new  TrainBean();
		String sql="select * from train where trainid=? ";
		try {
			PreparedStatement pst =conn.prepareStatement(sql);
						pst.setInt(1,id1);
						ResultSet rst=pst.executeQuery();
						rst.next();
						tb.setTrainId(rst.getInt(1));
						tb.setTrainType(rst.getString(2));
						tb.setSeats(rst.getInt(3));
						tb.setPlatformno(rst.getInt(4));
		
		} catch (SQLException e) {
		throw new TrainException("failed in fetching details :");
		}
		
		
		return tb;
	}

}
