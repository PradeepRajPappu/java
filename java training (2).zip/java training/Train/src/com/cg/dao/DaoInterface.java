package com.cg.dao;

import com.cg.beans.TrainBean;
import com.cg.exception.TrainException;

public interface DaoInterface {

	int addDetails(TrainBean tb) throws TrainException;

	TrainBean getDetailsWithId(int id1) throws TrainException;

}
