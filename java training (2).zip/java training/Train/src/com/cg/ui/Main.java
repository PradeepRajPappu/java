package com.cg.ui;

import java.util.Scanner;

import com.cg.beans.TrainBean;
import com.cg.exception.TrainException;
import com.cg.service.ServiceImpl;
import com.cg.service.ServiceInterface;

public class Main {
	
	public static void main(String[] args) {
		
		ServiceInterface si= new ServiceImpl();
		
	Scanner sc =new Scanner(System.in);
	do {
		System.out.println("1.add train details");
		System.out.println("2.Display train details");
		System.out.println("3.exit");
		System.out.println("enter your choice :");
		int choice = sc.nextInt();
		switch (choice) {
		case 1:
			System.out.println("enter Train type:");
			String trainType = sc.next();
			System.out.println("enter number of seats:");
			int seats = sc.nextInt();
			System.out.println("enter platform no:");
			int platform = sc.nextInt();

			TrainBean tb = new TrainBean(trainType, seats, platform);
			//System.out.println(tb);
			int id;
			try {
				id = si.addDetails(tb);
				System.out.println("details entered with id :" + id);
			} catch (TrainException e) {
				System.out.println(e.getMessage());
			}
			break;
		case 2:
			System.out.println("enter train id:");
			int id1 = sc.nextInt();
			TrainBean tb1;

			try {
				tb1 = si.getDetailsWithId(id1);
				System.out.println(tb1);

			} catch (TrainException e) {
				System.out.println(e.getMessage());
			}

			break;
		case 3:
			System.exit(0);
			break;
		default:
			System.out.println("enter valid choice");

		}
	} while (true);
	}
	
	
	}


