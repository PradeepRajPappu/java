package com.cg.service;

import com.cg.beans.TrainBean;
import com.cg.exception.TrainException;

public interface ServiceInterface {

	int addDetails(TrainBean tb) throws TrainException;

	TrainBean getDetailsWithId(int id1) throws TrainException;

}
