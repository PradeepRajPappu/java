package com.cg.service;

import com.cg.beans.TrainBean;
import com.cg.dao.DaoImpl;
import com.cg.dao.DaoInterface;
import com.cg.exception.TrainException;

public class ServiceImpl implements ServiceInterface{

	DaoInterface dao=new DaoImpl();
	
	
	
	
	
	
	
	
	
	@Override
	public int addDetails(TrainBean tb) throws TrainException {
	
		
		
		return dao.addDetails(tb);
	}
	@Override
	public TrainBean getDetailsWithId(int id1) throws TrainException {
		
		return dao.getDetailsWithId(id1);
	}

}
