package com.cg.demos;

import java.util.Scanner;




	
	public class Person{
					int age;
				String name;
				String address;
				
				Person(int age,String name,String address)
				{
					this.age=age;
					this.name=name;
					this.address=address;
				}
				
				Person(){
					
				Scanner in = new Scanner(System.in);
				System.out.println("enter the age");
				this.age=in.nextInt();
				System.out.println("enter name");
				this.name=in.next();
				System.out.println("enter the address");
				this.address=in.next();
				
				}
				
				void display(){
					System.out.println("age:"+age+"\n name:"+name+"\n address:"+address);
					
				}
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
	
		Person obj= new Person(25,"sravan","pune");
			obj.display();
			Person obj1= new Person();
			obj1.display();
		System.out.println("success");
	
	
	}

	}
