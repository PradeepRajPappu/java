import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;


public class PropertiesMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		FileInputStream fis= null;
		try {
			fis = new FileInputStream("Resource/JDBC.properties");
			Properties prop =new Properties();
			prop.load(fis);
			String driver=prop.getProperty("JDBC.Driver");
			String url=prop.getProperty("JDBC.URL");
			String user=prop.getProperty("JDBC.Userid");
			String password=prop.getProperty("JDBC.password");
			System.out.println(driver);
			System.out.println(url);
			System.out.println(user);
			System.out.println(password);

		//	prop=System.getProperties();
			//prop.list(System.out);
			
			
			

		} catch (FileNotFoundException e) {
			System.err.println(e.getMessage());

		} catch (IOException e) {
			System.err.println(e.getMessage());
		}
		
		
		finally{
			if(fis!=null)
				try {
					fis.close();
				} catch (IOException e) {
					System.err.println(e.getMessage());
				}



		}

	}
}