package com.cg.beans;

public class Manager {
private int grossSalary;
private int netSalary;
private int totalSalary;

public int calcMgrSalary()
{
	totalSalary=grossSalary+netSalary;
	
	return totalSalary;
	}

public Manager(int grossSalary, int netSalary) {
	super();
	this.grossSalary = grossSalary;
	this.netSalary = netSalary;
}


}