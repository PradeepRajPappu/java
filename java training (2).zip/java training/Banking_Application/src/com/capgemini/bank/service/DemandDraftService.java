package com.capgemini.bank.service;

import com.capgemini.bank.bean.DemandDraft;
import com.capgemini.bank.dao.DemandDraftDao;
import com.capgemini.bank.dao.IDemandDraftDAO;
import com.capgemini.bank.exception.BankException;

public class DemandDraftService implements IDemandDraftService {

	IDemandDraftDAO dao= new DemandDraftDao();
	@Override
	public int addDemandDraftDetails(DemandDraft DD) throws BankException {
		return dao.addDemandDraftDetails(DD);
	}
	@Override
	public DemandDraft getDemandDraftDetails(int tid) throws BankException {
		return dao.getDemandDraftDetails(tid);
	}

}
