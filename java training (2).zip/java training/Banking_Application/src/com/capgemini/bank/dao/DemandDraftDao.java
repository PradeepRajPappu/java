package com.capgemini.bank.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.capgemini.bank.bean.DemandDraft;
import com.capgemini.bank.dbutil.DBUtil;
import com.capgemini.bank.exception.BankException;




public class DemandDraftDao implements IDemandDraftDAO {
	Connection conn = null;
	@Override
	public int addDemandDraftDetails(DemandDraft dD) throws BankException {
		int id=generateid();
		conn = DBUtil.getConnection();
		try {
			String sql="INSERT INTO demand_draft VALUES(?,?,?,?,sysdate,?,?,?)";
			PreparedStatement pst = conn.prepareStatement(sql);
			pst.setInt(1,id );	
			pst.setString(2,dD.getCustomer_name());
			pst.setString(3,dD.getIn_favour_of());
			pst.setString(4,dD.getPhone_number());
			pst.setDouble(5,dD.getAmount());
			pst.setInt(6, dD.getDd_commission());
			pst.setString(7, dD.getDd_description());
			pst.executeUpdate();
		
		} catch (SQLException e) {
			throw new BankException("Error inserting data:");
		}
		return id;
	}
	private int generateid() throws BankException {

		int id = 0;
				String sql = "SELECT t_id.NEXTVAL FROM dual";
				conn = DBUtil.getConnection();
				try {
					Statement stmt = conn.createStatement();
					ResultSet rst = stmt.executeQuery(sql);
					rst.next();
					id = rst.getInt(1);
				} catch (SQLException e) {
					
					throw new BankException("Problem in generating  id "+ e.getMessage());
				}
				return id;
		
	}
	@Override
	public DemandDraft getDemandDraftDetails(int tid) throws BankException {
		DemandDraft dd;
		String sql="Select * from demand_draft where transaction_id=?";
		conn = DBUtil.getConnection();
		try {
			 dd=new DemandDraft();
			PreparedStatement pst = conn.prepareStatement(sql);
			pst.setInt(1,tid);
			ResultSet rst = pst.executeQuery();
	while(rst.next())
	{		dd.setTransaction_id(rst.getInt(1));
			dd.setCustomer_name(rst.getString(2));
			dd.setIn_favour_of(rst.getString(3));
			dd.setPhone_number(rst.getString(4));
			dd.setDate_of_transaction(rst.getDate(5));
			dd.setAmount(rst.getDouble(6));
			dd.setDd_commission(rst.getInt(7));
			dd.setDd_description(rst.getString(8));
	}		
		} catch (SQLException e1) {
		throw new BankException("problem in fetching");
		}
		
		
		
		
		return dd;
	}

}
