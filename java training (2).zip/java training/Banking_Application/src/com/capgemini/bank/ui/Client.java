package com.capgemini.bank.ui;

import java.sql.Date;
import java.util.Scanner;

import com.capgemini.bank.bean.DemandDraft;
import com.capgemini.bank.exception.BankException;
import com.capgemini.bank.service.DemandDraftService;
import com.capgemini.bank.service.IDemandDraftService;

public class Client {

	public static void main(String[] args) {
		IDemandDraftService ser= new DemandDraftService();
		Scanner sc=new Scanner(System.in);
		do {
			System.out.println("1.Enter Demand Draft Details: ");
			System.out.println("2.Print Demand Draft");
			System.out.println("3. Exit");
			System.out.println("Enter your choice :");
			int choice = sc.nextInt();
			switch (choice) {
			case 1:
				System.out.println("Enter customer name: ");
				String customer_name = sc.next();
				System.out.println("Enter phone number");
				String phone_number = sc.next();
				System.out.println("Enter in_favour_of");
				String in_favour_of = sc.next();
				System.out.println("Enter amount :");
				double amount = sc.nextDouble();
				int dd_commission = 0;

				if (amount >= 0 && amount <= 5000)
					dd_commission = 10;
				else if (amount > 5000 && amount <= 10000)
					dd_commission = 41;
				else if (amount > 10000 && amount <= 100000)
					dd_commission = 51;
				else if (amount > 100000 && amount <= 500000)
					dd_commission = 300;
				else
					System.out.println("enter proper amount: ");
				System.out.println("enter Remarks");
				String dd_description = sc.next();
				DemandDraft DD = new DemandDraft(customer_name, phone_number,
						in_favour_of, amount, dd_description, dd_commission);

				int id;
				try {
					id = ser.addDemandDraftDetails(DD);
					System.out.println("Added succefully with Transaction Id: "
							+ id);
				} catch (BankException e) {
					System.err.println(e.getMessage());
				}

				break;
			case 2:
				System.out.println("enter tid: ");
				int tid=sc.nextInt();
				DemandDraft de;
				try {
					de = ser.getDemandDraftDetails(tid);
					System.out.println(de);
				} catch (BankException e) {
					System.err.println(e.getMessage());
				}
			
				break;
			case 3:
				System.exit(0);
				break;

			}
		} while (true);
	
	}

}
