package com.capgemini.bank.bean;

import java.sql.Date;

public class DemandDraft {
	
	private String customer_name;
	private String phone_number;
	private String in_favour_of;
	private double amount;
	private String dd_description;
	private int transaction_id;
	private Date date_of_transaction;
	private int dd_commission;
	
	
	
	
	public DemandDraft(String customer_name, String phone_number,
			String in_favour_of, double amount, String dd_description,
			 int dd_commission) {
		super();
		this.customer_name = customer_name;
		this.phone_number = phone_number;
		this.in_favour_of = in_favour_of;
		this.amount = amount;
		this.dd_description = dd_description;
		this.transaction_id = transaction_id;
		this.date_of_transaction = date_of_transaction;
		this.dd_commission = dd_commission;
	}
	public DemandDraft() {
		// TODO Auto-generated constructor stub
	}
	public int getTransaction_id() {
		return transaction_id;
	}
	public void setTransaction_id(int transaction_id) {
		this.transaction_id = transaction_id;
	}
	public String getCustomer_name() {
		return customer_name;
	}
	public void setCustomer_name(String customer_name) {
		this.customer_name = customer_name;
	}
	public String getIn_favour_of() {
		return in_favour_of;
	}
	public void setIn_favour_of(String in_favour_of) {
		this.in_favour_of = in_favour_of;
	}
	public String getPhone_number() {
		return phone_number;
	}
	public void setPhone_number(String phone_number) {
		this.phone_number = phone_number;
	}
	public Date getDate_of_transaction() {
		return date_of_transaction;
	}
	public void setDate_of_transaction(Date date_of_transaction) {
		this.date_of_transaction = date_of_transaction;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	public int getDd_commission() {
		return dd_commission;
	}
	public void setDd_commission(int dd_commission) {
		this.dd_commission = dd_commission;
	}
	public String getDd_description() {
		return dd_description;
	}
	public void setDd_description(String dd_description) {
		this.dd_description = dd_description;
	}
	@Override
	public String toString() {
		return "DemandDraft [transaction_id=" + transaction_id
				+ ", customer_name=" + customer_name + ", in_favour_of="
				+ in_favour_of + ", phone_number=" + phone_number
				+ ", date_of_transaction=" + date_of_transaction + ", amount="
				+ amount + ", dd_commission=" + dd_commission
				+ ", dd_description=" + dd_description + "]";
	}
	
	
	
}
