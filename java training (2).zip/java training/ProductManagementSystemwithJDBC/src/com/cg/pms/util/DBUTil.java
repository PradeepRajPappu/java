package com.cg.pms.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import com.cg.pms.exceptions.ProductDbException;

public class DBUTil {

	private static Connection conn ;

	public static Connection getConnection() throws ProductDbException {
		if (conn == null) {
			try {
				Class.forName("oracle.jdbc.driver.OracleDriver");
				System.out.println("driver found");
				 conn = DriverManager.getConnection(
						"jdbc:oracle:thin:@ndaoracle:1521:ORCL11g",
						"lab01trg15", "lab01oracle");
				System.out.println("connection established");
			} catch (ClassNotFoundException e) {
				throw new ProductDbException("Driver not found"
						+ e.getMessage());
			} catch (SQLException e) {
				throw new ProductDbException(
						"Problem in establishng connection" + e.getMessage());

			}

		}

		return conn;
	}
}
