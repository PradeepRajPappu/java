package com.cg.pms.pl;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Scanner;

import com.cg.pms.beans.Order;
import com.cg.pms.beans.Product;
import com.cg.pms.exceptions.InvalidOrderException;
import com.cg.pms.exceptions.InvalidProductException;
import com.cg.pms.exceptions.ProductDbException;
import com.cg.pms.service.ProductService;
import com.cg.pms.service.ProductServiceImpl;

public class ProductMain {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		ProductService pser=new ProductServiceImpl();
		do {
			System.out.println("1.Add Product");
			System.out.println("2. Delete Product\n3. Show all products");
			System.out.println("4. place order\n5. exit");
			System.out.println("enter your choice :");
			int choice = sc.nextInt();
			switch (choice) {
			
			case 1:System.out.println("Enter Product name:");
			String pname=sc.next();
			System.out.println("enter product price:");
			double price =sc.nextDouble();
			Product p=new Product(0,pname,price);
			
				try {
					if(pser.validateProduct(p)){
						
						pser.addProduct(p);
						
						System.out.println("product inserted in table with id "+p.getProductId());
					}
				} catch (InvalidProductException e) {
				
						System.out.println(e.getMessage());
				} catch (ProductDbException e) {
				
						System.out.println(e.getMessage());
				}
			break;
			case 2:
				break;
			case 3:
				try {
					List<Product> plist =pser.getAllProduct();
					if(plist.size()==0)
						System.out.println("no products available");
					else {
						for(Product p1:plist)
							System.out.println(p1);
					}
				} catch (ProductDbException e) {
					System.out.println(e.getMessage());
				}
				break;
			case 4:
				System.out.println("enter product id to order :");
				int pid=sc.nextInt();
				System.out.println("enter quantity");
				int qty=sc.nextInt();
				System.out.println("enetr order date in dd/MM/yyyy format:");
				String ordDateStr=sc.next();
				DateTimeFormatter format= DateTimeFormatter.ofPattern("dd/MM/yyyy");
				LocalDate ordDate= LocalDate.parse(ordDateStr, format);
						Order order =new Order(0,pid,qty,0,ordDate);
				try {
					if(pser.searchProduct(pid)==null)
					{
						System.out.println("product not available with "+pid);
					}else{
					if(pser.validateOrder(order))
					{
						pser.addOrder(order);
						System.out.println("order placed with id "+order.getOrderId());
						System.out.println("total ammount to pay "+order.getTotalAmount());
					}}
				} catch (InvalidOrderException e) {
					System.out.println(e.getMessage());
				} catch (ProductDbException e) {
					System.out.println(e.getMessage());
				}
						
						break;
			case 5:System.exit(0);
				break;
				
			default:
				System.out.println("enter ");
			}
		} while (true);

	}

}
