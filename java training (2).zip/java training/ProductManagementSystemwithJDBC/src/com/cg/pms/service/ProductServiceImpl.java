package com.cg.pms.service;

import java.util.List;

import com.cg.pms.beans.Order;
import com.cg.pms.beans.Product;
import com.cg.pms.dao.ProductDao;
import com.cg.pms.dao.ProductDaoImp;
import com.cg.pms.exceptions.InvalidOrderException;
import com.cg.pms.exceptions.InvalidProductException;
import com.cg.pms.exceptions.ProductDbException;

public class ProductServiceImpl implements ProductService {

	ProductDao pdao=new ProductDaoImp();
	
	@Override
	public List<Product> getAllProduct() throws ProductDbException {
		return pdao.getAllProduct();
	}

	@Override
	public Product searchProduct(long productId) throws ProductDbException {
		return pdao.searchProduct(productId);
	}

	@Override
	public long addProduct(Product product) throws ProductDbException {
		return pdao.addProduct(product);
	}

	@Override
	public long addOrder(Order order) throws ProductDbException {
		Product p=pdao.searchProduct(order.getProductId());
		order.setTotalAmount(order.getQuantity()*p.getProductPrice());
		return pdao.addOrder(order);
	}

	@Override
	public long deleteProduct(long productId) throws ProductDbException {
		return pdao.deleteProduct(productId);
	}

	@Override
	public boolean validateProduct(Product product)
			throws InvalidProductException {
			if(product.getProductPrice()<=0)
				throw new InvalidProductException("price should not be negative or 0");
			if(product.getProductName().matches("[A-z][a-z]{8}"))
				throw new InvalidProductException("product name should start with caps ");
		return true;
	}

	@Override
	public boolean validateOrder(Order order) throws InvalidOrderException {
		if(order.getQuantity()<=0)
			throw new InvalidOrderException("quantity should not be 0");
		return true;
	}

}
