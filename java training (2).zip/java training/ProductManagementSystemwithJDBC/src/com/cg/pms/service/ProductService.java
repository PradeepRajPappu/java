package com.cg.pms.service;

import java.util.List;

import com.cg.pms.beans.Order;
import com.cg.pms.beans.Product;
import com.cg.pms.exceptions.InvalidOrderException;
import com.cg.pms.exceptions.InvalidProductException;
import com.cg.pms.exceptions.ProductDbException;

public interface ProductService {
	List<Product>getAllProduct() throws ProductDbException;
	Product searchProduct(long productId) throws ProductDbException;
	long addProduct(Product product) throws ProductDbException;
	long addOrder(Order order) throws ProductDbException;
	long deleteProduct(long productId) throws ProductDbException;
	boolean validateProduct(Product product) throws InvalidProductException;
	boolean validateOrder(Order order) throws InvalidOrderException;

}
