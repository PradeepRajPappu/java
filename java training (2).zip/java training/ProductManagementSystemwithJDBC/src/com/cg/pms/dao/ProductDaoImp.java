package com.cg.pms.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.cg.pms.beans.Order;
import com.cg.pms.beans.Product;
import com.cg.pms.exceptions.ProductDbException;
import com.cg.pms.util.DBUTil;

public class ProductDaoImp implements ProductDao {
	Connection conn = null;

	@Override
	public List<Product> getAllProduct() throws ProductDbException {
		String sql = "SELECT product_id, product_name, product_price FROM product";
		List<Product> plist = new ArrayList<Product>();
		conn = DBUTil.getConnection();
		try {
			Statement stmt = conn.createStatement();
			ResultSet rst = stmt.executeQuery(sql);
			while (rst.next()) {
				Product p = new Product();
				p.setProductId(rst.getLong("product_id"));
				p.setProductName(rst.getString("product_name"));
				p.setProductPrice(rst.getDouble("product_price"));
				plist.add(p);
			}
		} catch (SQLException e) {
			throw new ProductDbException("Problem in fetching product list"
					+ e.getMessage());
		}
		return plist;
	}

	@Override
	public Product searchProduct(long productId) throws ProductDbException {
		String sql = "SELECT product_id, product_name, product_price "
				+ " FROM product WHERE product_id=?";
		Product p = null;
		conn = DBUTil.getConnection();
		try {
			PreparedStatement pst = conn.prepareStatement(sql);
			pst.setLong(1, productId);
			ResultSet rst = pst.executeQuery();
			if (rst.next()) {
				p = new Product();
				p.setProductId(rst.getLong("product_id"));
				p.setProductName(rst.getString("product_name"));
				p.setProductPrice(rst.getDouble("product_price"));
			}
		} catch (SQLException e) {
			throw new ProductDbException("Problem in searching product "
					+ e.getMessage());
		}
		return p;
	}

	@Override
	public long addProduct(Product product) throws ProductDbException {
		String sql = "INSERT INTO product VALUES(?,?,?)";
		product.setProductId(generateProductId());
		conn = DBUTil.getConnection();
		try {
			PreparedStatement pst = conn.prepareStatement(sql);
			pst.setLong(1, product.getProductId());
			pst.setString(2, product.getProductName());
			pst.setDouble(3, product.getProductPrice());
			pst.executeUpdate();
		} catch (SQLException e) {
			throw new ProductDbException("Problem in inserting product"
					+ " details " + e.getMessage());
		}
		return product.getProductId();
	}

	private long generateProductId() throws ProductDbException {
		long pid = 0;
		String sql = "SELECT Product_seq.NEXTVAL FROM dual";
		conn = DBUTil.getConnection();
		try {
			if (conn == null)
				System.out.println(conn);
		Statement stmt=conn.createStatement();
			ResultSet rst = stmt.executeQuery(sql);
			rst.next();
			pid = rst.getLong(1);
		} catch (SQLException e) {
			throw new ProductDbException("Problem in generating product id "
					+ e.getMessage());
		}
		return pid;
	}

	@Override
	public long addOrder(Order order) throws ProductDbException {
		String sql = "INSERT INTO product_Order values(?,?,?,?,?)";
		order.setOrderId(generateOrderID());
		System.out.println(order);
		conn = DBUTil.getConnection();
		try {
			PreparedStatement pst = conn.prepareStatement(sql);
			pst.setLong(1, order.getOrderId());
			pst.setLong(2, order.getProductId());
			pst.setInt(3, order.getQuantity());
			pst.setDouble(4, order.getTotalAmount());
			pst.setDate(5, Date.valueOf(order.getOrderdate()));
			pst.executeUpdate();
		} catch (SQLException e) {
			throw new ProductDbException("Problem in inserting order "
					+ "details " + e.getMessage());
		}

		return order.getOrderId();
	}

	private long generateOrderID() throws ProductDbException {
		long oid = 0;
		String sql = "SELECT Order_seq.NEXTVAL FROM dual";
		conn = DBUTil.getConnection();
		try {
			Statement stmt = conn.createStatement();
			ResultSet rst = stmt.executeQuery(sql);
			rst.next();
			oid = rst.getLong(1);
		} catch (SQLException e) {
			throw new ProductDbException("Problem in generating product id "
					+ e.getMessage());
		}
		return oid;
	}

	@Override
	public long deleteProduct(long productId) throws ProductDbException {
		// TODO Auto-generated method stub
		return 0;
	}

}
