package com.cg.pms.dao;

import java.util.List;

import com.cg.pms.beans.Order;
import com.cg.pms.beans.Product;
import com.cg.pms.exceptions.ProductDbException;

public interface ProductDao {
	List<Product>getAllProduct() throws ProductDbException;
	Product searchProduct(long productId) throws ProductDbException;
	long addProduct(Product product) throws ProductDbException;
	long addOrder(Order order) throws ProductDbException;
	long deleteProduct(long productId) throws ProductDbException;
	

}
