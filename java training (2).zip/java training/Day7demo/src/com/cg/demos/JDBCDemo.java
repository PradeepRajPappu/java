package com.cg.demos;

import java.sql.PreparedStatement;
import java.sql.Statement;
import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;


public class JDBCDemo {

	public static void main(String[] args) {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			System.out.println("driver found");
			Connection conn =DriverManager.getConnection("jdbc:oracle:thin:@ndaoracle:1521:ORCL11g","lab01trg15","lab01oracle");
			System.out.println("connection established");
			
			/*Statement stmt=conn.createStatement();
			String sql="Select empno, ename,sal From emp";
			ResultSet rst=stmt.executeQuery(sql);
			
			while(rst.next()){
				System.out.print(rst.getInt("empno")+" ");
				System.out.print(rst.getString("ename")+" ");
				System.out.println(rst.getInt("sal")+" ");
			}
			*/
			
			
			Scanner sc= new Scanner(System.in);
			System.out.println("enter deptno:");
			int deptno=sc.nextInt();
			String sql="Select empno, ename,sal From emp WHERE deptno = ?";
			PreparedStatement pst=conn.prepareStatement(sql);
			pst.setInt(1, deptno);
				ResultSet rst=pst.executeQuery();
			
			while(rst.next()){
				System.out.print(rst.getInt("empno")+" ");
				System.out.print(rst.getString("ename")+" ");
				System.out.println(rst.getInt("sal")+" ");
			}
			
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

}
