package com.cg.demos;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class JDBCDemo1 {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		String sql="INSERT INTO emp(empno,ename,deptno) values(?,?,?)";
		System.out.println("enter empno:");
		int eno=sc.nextInt();
		System.out.println("enter employee name: ");
		String ename=sc.next();
		System.out.println("enter dept number: ");
		int deptno=sc.nextInt();
		
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			System.out.println("driver found");
			Connection conn =DriverManager.getConnection("jdbc:oracle:thin:@ndaoracle:1521:ORCL11g","lab01trg15","lab01oracle");
			System.out.println("connection established");
		
			PreparedStatement pst=conn.prepareStatement(sql);
			pst.setInt(1, eno);
			pst.setString(2,ename);
			pst.setInt(3, deptno);
				int count =pst.executeUpdate();
			System.out.println(count+" Rows inserted..!");
				
				
		} catch (ClassNotFoundException e) {
		
			e.printStackTrace();
		} catch (SQLException e) {
		
			e.printStackTrace();
		}
	}

}
