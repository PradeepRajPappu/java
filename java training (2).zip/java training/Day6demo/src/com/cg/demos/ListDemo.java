package com.cg.demos;

import java.awt.List;
import java.util.ArrayList;
import java.util.Iterator;

public class ListDemo {

	public static void main(String[] args) {
		
		/*ArrayList List;
		List<String> list =new ArrayList<>();*/
		
		ArrayList<String> list =new ArrayList<>();
		list.add("On");
		list.add("Two");
		list.add("Three");
		list.add(1,"One");
		list.add("Four");
		/*System.out.println(list);
		System.out.println(list.contains("Four"));

		list.remove(1);
		System.out.println(list);
		list.remove("Three");
		System.out.println(list);*/

		/*Iterator<String> itr =list.iterator();
		while(itr.hasNext()){
			String str =itr.next();
			System.out.println(str);
		}*/

		
		for(String str:list)
		{
			System.out.println(str);
		}
		
		
		

	}

}
