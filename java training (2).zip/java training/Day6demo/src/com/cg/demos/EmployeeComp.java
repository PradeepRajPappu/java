package com.cg.demos;

import java.util.Comparator;



public class EmployeeComp implements Comparator<EmployeeT> {

	@Override
	public int compare(EmployeeT o1, EmployeeT o2) {
		return o1.getName().compareTo(o2.getName());
	}
	
}





