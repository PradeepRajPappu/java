package com.cg.demos;

import java.util.HashMap;
import java.util.Set;

public class MapDemo {

	public static void main(String[] args) {
		HashMap<String, String> map = new HashMap<>();
		map.put("India", "delhi");
		map.put("Nepal", "islamabad");
		map.put("srilanka", "Comlombo");
		System.out.println(map);
		
		Set<String> keys= map.keySet();
		for(String k:keys){
			System.out.println(k+"-->"+map.get(k));
		
		}
	
	
	}

}
