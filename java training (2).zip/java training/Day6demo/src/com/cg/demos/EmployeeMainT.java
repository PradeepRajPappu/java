package com.cg.demos;


import java.util.Set;
import java.util.TreeSet;

public class EmployeeMainT {
	public static void main(String[] args) {
	
		EmployeeComp ecomp =new EmployeeComp();
		
			Set<EmployeeT> staff=new TreeSet<>(ecomp);
			staff.add(new EmployeeT(1002,"Shyam",20));
			staff.add(new EmployeeT(1001,"Ram",10));
		
			staff.add(new EmployeeT(1003,"Sita",10));
	
			
			System.out.println(staff);
	}
}
