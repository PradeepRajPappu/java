package com.cg.demos;

import java.util.HashSet;
import java.util.Set;

public class EmployeeMain {
	public static void main(String[] args) {
	
			Set<Employee> staff=new HashSet<>();
			staff.add(new Employee(1001,"Ram",10));
			staff.add(new Employee(1002,"Shyam",20));
			staff.add(new Employee(1003,"Sita",10));
	
			
			System.out.println(staff);
	}
}
