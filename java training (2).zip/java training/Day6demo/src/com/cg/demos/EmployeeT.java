package com.cg.demos;

public class EmployeeT implements Comparable<EmployeeT> {
	
	private int empno;
	private String name;
	private int deptno;
	
	
	
	@Override
	public int compareTo(EmployeeT o) {
		
		//return this.empno - o.empno;     //accordng to emno sorting order
	
		return this.name.compareTo(o.name); //acc to name sorting
	
	}
	
	
	
	
	public EmployeeT() {
		super();
	}
	
	
	public EmployeeT(int empno, String name, int deptno) {
		super();
		this.empno = empno;
		this.name = name;
		this.deptno = deptno;
	}

	@Override	//becoz hash tag compare obj's for uniqueness
	public boolean equals(Object obj) {
		if(obj instanceof EmployeeT){
			EmployeeT e=(EmployeeT)obj;
			if(e.empno == this.empno && e.name.equals(name)){
				return true;
			}
		}
		
		
		return false;
	}
	
	
	
	
	public int getEmpno() {
		return empno;
	}
	public void setEmpno(int empno) {
		this.empno = empno;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getDeptno() {
		return deptno;
	}
	public void setDeptno(int deptno) {
		this.deptno = deptno;
	}
	
	@Override
	public String toString(){
		return"\nEmployee [empno=" + empno + ",name=" + name + ",deptno=" +deptno+ "]";
	}
	

}
