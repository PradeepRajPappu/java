package com.cg.demos;

import java.util.HashSet;
import java.util.Set;
import java.util.TreeSet;

public class SetDemo {

	public static void main(String[] args) {
	/*Set<String> set = new HashSet<>();
	set.add("One");
	set.add("two");
	set.add("Three");
	set.add("four");
	
	System.out.println(set);

	set.add("two");
	set.add("Three");
	System.out.println(set);
	System.out.println(set.isEmpty());
	System.out.println(set.contains("four"));
*/	
	Set<Integer> set = new TreeSet<>();
	set.add(1);
	set.add(10);
	set.add(9);
	set.add(2);
	
	System.out.println(set);

	set.add(17);
	set.add(14);
	System.out.println(set);
	System.out.println(set.isEmpty());
	System.out.println(set.contains(1));
	
	
	
	}
}
