package com.cg.demos;

import java.util.Scanner;

class InvalidAgeException extends Exception {
	public InvalidAgeException(){
		super("invalid age entered..");
	}
}


public class ExceptionDemo {
	
	
	public static int acceptDetails() throws InvalidAgeException {
		Scanner sc =new Scanner(System.in);
	System.out.println("Enter your age ");
	int age=sc.nextInt();
	if(age<0) throw new InvalidAgeException();
	return age;
	}
	
	public static void main(String[] args){
		try {
			acceptDetails();
			System.out.println("entered valid age");
		} catch (InvalidAgeException e) {
		//	e.printStackTrace();
			System.out.println(e.getMessage());
		}
	
	
	/*public static void loadClass(String classname)
		throws ClassNotFoundException{
		Class.forName(classname);
		System.out.println("Class loaded");
	}
		
public static void main(String[] args){
	Scanner sc = new Scanner(System.in);
	System.out.println("enter class name");
	String name=sc.next();
	try{
	loadClass(name);
	System.out.println("class loaded...");
	}catch(ClassNotFoundException e){
	System.out.println("class not found");
	}*/
//sc.close();	

}
	
	
	
	}

