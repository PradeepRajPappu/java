		package com.cg.day4.pl;

import java.util.Scanner;

import com.cg.day4.service.ProductServiceImpl;
import com.cg.day4.bean.Product;


public class ProductMain {

	public static void main(String[] args) {
		Scanner sc =new Scanner(System.in);
		Product p=new Product();
		ProductServiceImpl pser =new ProductServiceImpl();
		do{
			System.out.println("menu");
			System.out.println("1.Enter product details:");
			System.out.println("2.Order for Product:");
			System.out.println("3.Exit");
			System.out.println("Enter your choice:");
			int choice=sc.nextInt();
			switch(choice){

			case 1:
				System.out.println("enter product id:");
				int pid =sc.nextInt();
				System.out.println("enter pro name:");
				String pname=sc.next();
				System.out.println("enter pro price:");
				double pprice=sc.nextDouble();
				p.setProductId(pid);
				p.setProductName(pname);
				p.setPrice(pprice);
				break;
			case 2:
				System.out.println("enter quantity for order");
				int quantity =sc.nextInt();
				double totalAmt=pser.calculateTotalAmount(p,quantity);
				System.out.println("you have to pay:"+totalAmt+" Rupees only for this order");
				break;
			case 3:
				System.exit(0);
			default:System.out.println("Invalid choice.. try again");

			}
		}while(true);

	}

}


