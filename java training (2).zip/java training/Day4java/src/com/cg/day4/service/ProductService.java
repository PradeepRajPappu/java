package com.cg.day4.service;

import com.cg.day4.bean.Product;

public interface ProductService {
	double calculateTotalAmount(Product product,int quantity);

}
