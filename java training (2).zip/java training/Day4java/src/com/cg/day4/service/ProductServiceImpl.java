package com.cg.day4.service;

import com.cg.day4.bean.Product;

public class ProductServiceImpl	implements ProductService {
	@Override
	public double calculateTotalAmount(Product product,int quantity)
	{double totalAmount;
	totalAmount=product.getPrice()*quantity;
	return totalAmount;
	}

}
