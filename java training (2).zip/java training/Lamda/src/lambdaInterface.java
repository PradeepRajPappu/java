
public interface lambdaInterface {

}
