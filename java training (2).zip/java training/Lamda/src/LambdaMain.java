
public class LambdaMain {

	public static void main(String[] args) {
	lambdaInterface li;
	/*Declaration part*/ // ->  /*implemet code*/

	
	
	
	
	}

}
