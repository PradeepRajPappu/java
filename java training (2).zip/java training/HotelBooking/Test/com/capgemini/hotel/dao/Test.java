package com.capgemini.hotel.dao;

import static org.junit.Assert.*;

import org.junit.BeforeClass;
import com.capgemini.hotel.bean.CustomerBean;




public class Test {

	/*@org.junit.Test
	public void test() {
		fail("Not yet implemented");
	}*/
	static ICustomerBookingDao dao;
	CustomerBookingDao Dao;
	static CustomerBean cb;
	
	@BeforeClass
	public static void init()
	{
		dao=new CustomerBookingDao() ;
		cb=new CustomerBean("Raju","raju@gmail","9652651520","hyd");	
	
	}
	
	@org.junit.Test
	public void TestAddCustomerDetails()
	{ 
		
		assertNotNull(dao.addCustomerDetails(cb));
		
		
	}
	
	
	
}
