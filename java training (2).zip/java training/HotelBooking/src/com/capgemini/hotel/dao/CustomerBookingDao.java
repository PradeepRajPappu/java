package com.capgemini.hotel.dao;

import java.util.HashMap;
import java.util.Map;

import com.capgemini.hotel.bean.CustomerBean;
import com.capgemini.hotel.bean.RoomBooking;

public class CustomerBookingDao implements ICustomerBookingDao {
	Map<Integer, CustomerBean> customerDetails = new HashMap<>();
	public static Map<Integer, String> roomDetails = new HashMap<>();
	public CustomerBookingDao(){
		roomDetails.put(101,"AC_SINGLE");
		roomDetails.put(102,"AC_SINGLE");
		roomDetails.put(103,"AC_DOUBLE");
		roomDetails.put(201,"NONAC_SINGLE");
		roomDetails.put(202,"NONAC_SINGLE");
		roomDetails.put(203,"NONAC_DOUBLE");
			
	}
	
	

	@Override
	public int addCustomerDetails(CustomerBean cb) {
		int id = 0;
		customerDetails.put(cb.getCustomerId(), cb);
		return cb.getCustomerId();
	}
	@Override
	public RoomBooking getBookingDetails(int customerId) {
		
		RoomBooking rb=new RoomBooking(0,null, customerId);
		
		
		
		return rb;
	}

}
