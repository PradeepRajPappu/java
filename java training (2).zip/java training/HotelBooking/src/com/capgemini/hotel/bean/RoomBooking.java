package com.capgemini.hotel.bean;

public class RoomBooking {
	
	private int roomNO;
	private String roomType;
//	CustomerBean rcb;
	private int customerId;
	
	

	



	public int getCustomerId() {
		return customerId;
	}



	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}



	public int getRoomNO() {
		return roomNO;
	}



	public void setRoomNO(int roomNO) {
		this.roomNO = roomNO;
	}



	public String getRoomType() {
		return roomType;
	}



	public void setRoomType(String roomType) {
		this.roomType = roomType;
	}






	


	@Override
	public String toString() {
		return "RoomBooking [roomNO=" + roomNO + ", roomType=" + roomType
				+ ", customerId=" + customerId + "]";
	}



	public RoomBooking(int roomNO, String roomType,int customerId) {
		super();
		this.roomNO = roomNO;
		this.roomType = roomType;
		this.customerId = customerId;
	}







	public RoomBooking() {
		// TODO Auto-generated constructor stub
	}

}
