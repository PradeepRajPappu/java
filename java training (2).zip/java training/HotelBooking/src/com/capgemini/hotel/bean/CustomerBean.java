package com.capgemini.hotel.bean;

public class CustomerBean {
	
	private String customerName;
	private String email;
	private String phoneNo;
	private String address;
	private int customerId;
	
	static int generator=1000;
	

	public CustomerBean(String customerName, String email, String phoneNo,
			String address) {
		super();
		this.customerName = customerName;
		this.email = email;
		this.phoneNo = phoneNo;
		this.address = address;
		this.customerId=(int)(Math.random()*100);
	}



	public String getCustomerName() {
		return customerName;
	}



	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}



	public String getEmail() {
		return email;
	}



	public void setEmail(String email) {
		this.email = email;
	}



	public String getPhoneNo() {
		return phoneNo;
	}



	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}



	public String getAddress() {
		return address;
	}



	public void setAddress(String address) {
		this.address = address;
	}



	public int getCustomerId() {
		return customerId;
	}



	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}



	@Override
	public String toString() {
		return "CustomerBean [customerName=" + customerName + ", email="
				+ email + ", phoneNo=" + phoneNo + ", address=" + address + "]";
	}



	public CustomerBean() {
		// TODO Auto-generated constructor stub
	}

}
