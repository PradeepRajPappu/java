package com.capgemini.hotel.ui;

import java.util.ArrayList;
import java.util.Scanner;

import com.capgemini.hotel.bean.CustomerBean;
import com.capgemini.hotel.bean.RoomBooking;
import com.capgemini.hotel.exception.HotelException;
import com.capgemini.hotel.service.HotelService;
import com.capgemini.hotel.service.IHotelService;

public class Client {

	public static void main(String[] args) {
		IHotelService serv = new HotelService();
		
		
		Scanner sc = new Scanner(System.in);
		 String roomType=null;
		 int roomNumber=0;
		 CustomerBean cb=null;
		do {
			System.out.println("***********************************");
			System.out.println("1.Book Room ");
			System.out.println("2.View Booking Details ");
			System.out.println("3.Exit");
			System.out.println("Enter Choice");
			System.out.println("***********************************");
			int choice = sc.nextInt();
			switch (choice) {
			case 1:
				System.out.println("Enter Customer Name");
				String customerName = sc.next();
				System.out.println("Enter Email");
				String email = sc.next();
				System.out.println("Enter phoneNumber");
				String phoneNo = sc.next();
				System.out.println("Enter Address");
				String address = sc.next();
				System.out.println("101 AC_SINGLE");
				System.out.println("102 AC_SINGLE");
				System.out.println("103 AC_DOUBLE");
				System.out.println("201 NONAC_SINGLE");
				System.out.println("202 NONAC_SINGLE");
				System.out.println("203 NONAC_DOUBLE");
				System.out.println("valid Room Number ");
				roomNumber = sc.nextInt();
				//	 String roomType=null;
				if (roomNumber == 101) {
					roomType = "AC_SINGLE";
				} else if (roomNumber == 102) {
					roomType = "AC_SINGLE";
				} else if (roomNumber == 103) {
					roomType = "AC_DOUBLE";
				} else if (roomNumber == 201) {
					roomType = "NONAC_SINGLE";
				} else if (roomNumber == 202) {
					roomType = "NONAC_SINGLE";
				} else if (roomNumber == 203) {
					roomType = "NONAC_DOUBLE";
				}
				//	 RoomBooking rb1  = new RoomBooking(roomNumber, roomType);
				cb = new CustomerBean(customerName, email,
						phoneNo, address);
				int id=0;
				try {
					if(serv.validateCus(cb))
					{
					id = serv.addCustomerDetails(cb);
					System.out.println("Your room has been successfully booked, your customer Id is "
							+ id);
					}
				} catch (HotelException e) {
					System.err.println(e.getMessage());
				}
				
				break;

			case 2:
				System.out.println("Enter Customer Id");
				int customerId = sc.nextInt();
				RoomBooking rb = serv.getBookingDetails(customerId);
				
				System.out.println("***********************************");
				System.out.println("Name"+cb.getCustomerName());
				System.out.println("RoomNo:" + roomNumber);
				System.out.println("RoomType:" + roomType);
				System.out.println("***********************************");

				break;
			case 3:
				System.exit(0);

				break;
			default:

			}
		} while (true);
		
	}

}
