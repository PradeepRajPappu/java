package com.capgemini.hotel.service;

import java.util.regex.Pattern;



import com.capgemini.hotel.bean.CustomerBean;
import com.capgemini.hotel.bean.RoomBooking;
import com.capgemini.hotel.dao.CustomerBookingDao;
import com.capgemini.hotel.dao.ICustomerBookingDao;
import com.capgemini.hotel.exception.HotelException;


public class HotelService implements IHotelService {
ICustomerBookingDao dao = new CustomerBookingDao();
	@Override
	public int addCustomerDetails(CustomerBean cb) {
		// TODO Auto-generated method stub
		return dao.addCustomerDetails (cb);
	}
	@Override
	public RoomBooking getBookingDetails(int customerId) {
		// TODO Auto-generated method stub
		return dao.getBookingDetails(customerId);
	}
	@Override
	public boolean validateCus(CustomerBean cb) throws HotelException {
		
		Boolean flag=true;
		String nameEx="^[A-Z][a-z]{3,19}$";
		String phonenoEx="^[6-9][0-9]{9}$";
		if(!Pattern.matches((nameEx),cb.getCustomerName()))
		{
			flag=false;
			throw new HotelException("Name should start with capitalletters and size should be 4 to 20 ......!\nex:Raju");
			
		}
		else if(!Pattern.matches("^[A-Za-z0-9_-]+[@][a-z]+[.][a-z]+$",cb.getEmail()))
		{	
			flag=false;
			throw new HotelException("enter valid MailId ..!\nex:kanaka_raju007@gmail.com");
		}	
		else if(!Pattern.matches(phonenoEx,cb.getPhoneNo()))
		{	
			flag=false;
			throw new HotelException("enter valid mobile number...!");
		}
		
		
		
		return flag;
	}
	
}
