package com.capgemini.hotel.service;

import com.capgemini.hotel.bean.CustomerBean;
import com.capgemini.hotel.bean.RoomBooking;
import com.capgemini.hotel.exception.HotelException;

public interface IHotelService {

	int addCustomerDetails(CustomerBean cb);

	RoomBooking getBookingDetails(int customerId);

	boolean validateCus(CustomerBean cb) throws HotelException;

}
