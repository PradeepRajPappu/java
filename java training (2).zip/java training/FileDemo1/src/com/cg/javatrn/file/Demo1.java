package com.cg.javatrn.file;

public class Demo1 {

}
