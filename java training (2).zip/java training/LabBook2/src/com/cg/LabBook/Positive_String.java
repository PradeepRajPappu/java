package com.cg.LabBook;

import java.awt.peer.ScrollbarPeer;
import java.util.Scanner;

public class Positive_String {

	boolean pos_string(String str){
		int i;
		char[] str_arr=str.toCharArray();
		for(i=0;i<str.length()-2;i++)
		{

			if(str_arr[i]<str_arr[i+1])
			{
				continue;
			}else 
			{return false;}

		}

		return true;
	}


	public static void main(String[] args) {
		String str;
		Scanner in= new Scanner(System.in);
		System.out.println("enter string to check:");
		str=in.next();
		Positive_String obj= new Positive_String();
		if(obj.pos_string(str))
		{
			System.out.println(str+" is positve number");
		}else{
			System.out.println(str+" is negative number");
		}

	}

}
