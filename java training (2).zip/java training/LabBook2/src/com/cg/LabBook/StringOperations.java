package com.cg.LabBook;

import java.util.Scanner;

public class StringOperations {

	static void add_string(String str1,String str2)
	{
		String str;
		str=str1+str2;						//to combine 2 strings
		System.out.println("concatinated string: "+str);
	}


	static void replace_string(String str)
	{
		StringBuilder str1=new StringBuilder(str); // string builder to modify string
		char odd_char='#';
		int i;
		str1.setCharAt(0,odd_char);   //particular position replace with odd_char
										
		for(i=0;i<str1.length();i++)
		{
			if((i%2)!=0)
			{
				str1.setCharAt(i+1,odd_char);
				
			}
		}
		System.out.println("replaced string "+str1);
	}

	static void remove_duplicates(String str)
	{String string;
	int i=0,j=0,cnt=0;
	char[] str_arr=str.toCharArray();

	for(i=0;i<str.length();i++)
	{	cnt=0;
	for(j=0;j<str.length();j++)
	{

		if(str_arr[i]==str_arr[j])
		{
			cnt++;
			if(cnt>1)	
			{
				str_arr[j]=' '; //adding space to repeated chars

			}
		}

	}
	}
	string=new String(str_arr);
	String nospacestr=string.replaceAll(" ",""); //removing all spaces

	System.out.println("unique char string: "+nospacestr);
	}

	static void odd_chars_to_upper(String str){
		StringBuilder str1=new StringBuilder(str);//string builder for editing
		int i;
		for(i=0;i<str1.length()+1;i++)
		{
			if((i%2)!=0)
			{
				
				if(Character.isLowerCase(str.charAt(i-1))) //checking is it lower
						{
							str1.setCharAt(i-1,Character.toUpperCase(str.charAt(i-1))); //converting lower to upper particular position
						}
			}
		}
		System.out.println("coverted  string "+str1);
		
	}
	
	
	


	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
		int i;
		String str1,str2;
		do{
			System.out.println("enter ur choice");
			System.out.println("1.add_string\n2.replace_string\n3.remove_duplicates\n4.odd_chars_to_upper case\n5.exit\n");
			i=sc.nextInt();
			switch(i)
			{
			case 1: 
				System.out.println("enter string1");
				str1=sc.next();
				System.out.println("enter string2");
				str2=sc.next();
				add_string(str1,str2);
				break;
			case 2:System.out.println("enter string to replace odd terms with #");
			str1=sc.next(); 
			replace_string(str1);
			break;
			case 3:System.out.println("enter string to remove duplicates");
			str1=sc.next(); 
			remove_duplicates(str1);
			break;
				case 4:System.out.println("enter string to covert odd palces to upper case");
				str1=sc.next(); 
					odd_chars_to_upper(str1);
				break;
			case 5 :System.exit(0);
			break;
			default: System.out.println("enter correct choice");

			}
		}while(true);
	}
}


