package com.cg.Date;

import java.time.LocalDate;
import java.time.Month;
import java.time.Period;
import java.time.temporal.ChronoUnit;
import java.util.Scanner;

public class Period_days {
	void Duration()
	{
		LocalDate start=LocalDate.of(1947,Month.AUGUST,15);
		LocalDate end=LocalDate.of(2019,Month.MAY,10);
		
		Period period=start.until(end);
		
		System.out.println("Days:"+period.get(ChronoUnit.DAYS));
		System.out.println("Months:"+period.get(ChronoUnit.MONTHS));
		System.out.println("Years:"+period.get(ChronoUnit.YEARS));
	}
	
	
	public static void main(String[] args) {
		Duration_days obj= new Duration_days();
		obj.Duration();
	}
}
