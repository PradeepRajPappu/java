package com.cg.main;

import java.util.Scanner;

import com.cg.beans.Employee;

public class Main {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int grossSal;
		int netSal;
		int eGrossSal;
		int eNetSal;
		System.out.println("enter mgr grosssal:");
		grossSal=sc.nextInt();
		System.out.println("enter mgr netssal:");
		netSal=sc.nextInt();
		System.out.println("enter emp grosssal:");
		eGrossSal=sc.nextInt();
		System.out.println("enter emp netssal:");
		eNetSal=sc.nextInt();
		Employee e=new Employee(grossSal,netSal,eGrossSal,eNetSal);
		e.Display();
		

	}

}
