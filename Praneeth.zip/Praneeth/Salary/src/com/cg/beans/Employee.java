package com.cg.beans;

public class Employee extends Manager {

	private int eGrossSalary;
	private int eNetSalary;
	private int eTotalSalary;

	public int CalcEmpSalary()
	{
		this.eTotalSalary=this.eGrossSalary+this.eNetSalary;

		return this.eTotalSalary;
	}




	public Employee(int grossSalary, int netSalary, int eGrossSalary,
			int eNetSalary) {
		super(grossSalary, netSalary);
		this.eGrossSalary = eGrossSalary;
		this.eNetSalary = eNetSalary;
	
	}


	public void Display()
	{
		
		System.out.println("Manager salary is:"+this.calcMgrSalary());
		System.out.println("Employee salary is:"+this.CalcEmpSalary());
	}


}
