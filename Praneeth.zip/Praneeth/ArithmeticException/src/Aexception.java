import java.util.Scanner;


public class Aexception {

	public static void main(String[] args) {
		Scanner sc =new Scanner(System.in);
		int i,j,div;
		System.out.println("enter 1st number");
		i=sc.nextInt();
		System.out.println("enter 2nd number as 0 to get exception");
		j=sc.nextInt();
		try{
			div=i/j;
			System.out.println("value="+div);
		}catch(ArithmeticException e){
			System.err.println("divide by 0 exception..");
			
		}

	}

}
