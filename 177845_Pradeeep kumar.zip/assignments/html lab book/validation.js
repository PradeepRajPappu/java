function validation()
{
	var x=document.forms["form1"]["name"].value;
	var y=document.forms["form1"]["sub1"].value;
	if(x == null || x==" ")
	{
		alert("name cant be blank");
		return false;
	}
	if(parseInt(y) < 0)
	{
		alert("enter positive number");
		return false;
	}
	return true;
}